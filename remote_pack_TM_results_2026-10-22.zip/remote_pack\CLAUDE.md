# CLAUDE.md — read this first

You are Claude (Sonnet 5.5, Claude Code) on a PC that has Ansys products installed. This folder
is a self-contained task pack from a larger research project. You bring results back; you do not
rewrite the project.

1. Read `README_PACK.md` (two minutes). It tells you which brief applies to the product on this
   machine:
   - **Ansys Lumerical** installed → follow `EXECUTION_TM_LUMERICAL.md`.
   - **Ansys Zemax OpticStudio, Premium or Enterprise edition** installed → follow
     `EXECUTION_TM_OPTICSTUDIO.md`.
   - Both installed → do the Lumerical brief first (no licence risk), then the OpticStudio one.
2. Read the whole brief before running anything. Run every script from inside `code/`, with a
   Windows Python (not WSL).
3. Rules that apply to everything you write: British English; every claim carries a status and a
   date (`VERIFIED <date>`, `ASSUMED`, `UNTESTED`); never tune or fabricate a number; fail loudly
   (a failed run writes `*.FAILED.csv`, never overwrites a good table); never hand-edit `.zmx`,
   `.zar`, `.fsp` or any binary; verdict first, evidence after; do not modify anything under
   `reference/`, `lumerical/ansys_example/` or `zemax/ansys_kba/`.
4. If a licence, an access control or a missing product blocks a step, say exactly what and stop
   there. Do not work around a licence.
5. When done, follow `RETURN.md`.
