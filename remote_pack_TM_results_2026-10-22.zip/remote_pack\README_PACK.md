# README_PACK — the TM (p-polarisation) leg of the F-PSM volume-grating benchmark

*Pack built 2026-10-16 on the benchmark PC from `1_Optics/Research/2026-10-16/`. British English.*

## What this is about, in one paragraph

A closed-form diffraction-efficiency model for volume holographic gratings, **F-PSM**, has been
benchmarked for **TE (s) polarisation** against Kogelnik's theory, an independent rigorous
coupled-wave (RCWA) referee written in Python, and the RCWA solvers of Ansys Zemax OpticStudio (a
user-defined hologram DLL) and Ansys Lumerical (the RCWA solver with layer repetition). That work
is complete and verified (September 2026). The model's author now asks for the same treatment of
**TM (p) polarisation**. The Python side of the TM benchmark is done and gated (this pack carries
the TM referee and TM Kogelnik, VERIFIED 2026-10-16). **What is missing is the Ansys TM data**:
the Lumerical p-polarisation tables and the OpticStudio TM tables (native Kogelnik object and RCWA
DLL). This pack exists to produce them. F-PSM itself has no TM formulae yet; nothing in this pack
asks you to invent them.

## The two briefs

| product on this machine | brief | produces |
|---|---|---|
| Ansys Lumerical (2025 R1 or later, RCWA solver licensed) | `EXECUTION_TM_LUMERICAL.md` | `results/lumerical_rcwa_<case>_TM.csv` ×5, a re-run of the TE tables, a complete probe dump, a TM convergence ladder, a verdict |
| Ansys Zemax OpticStudio, **Premium or Enterprise** (the DLL kills a Professional seat) | `EXECUTION_TM_OPTICSTUDIO.md` | `results/zemax_<case>_TM.csv` ×4 (native Kogelnik, Jy = 1), `results/zemax_rcwa_<case>_TM.csv` ×4 (RCWA DLL), a TM probe, a verdict |

Each brief has: the job, the physics in brief, the pack contents, the environment, a numbered
procedure, acceptance gates with the reference numbers to hit, the pitfalls already paid for, and a
deliverables checklist.

## Layout

```
CLAUDE.md                        start here
README_PACK.md                   this file
EXECUTION_TM_LUMERICAL.md        brief 1
EXECUTION_TM_OPTICSTUDIO.md      brief 2
RETURN.md                        what to bring back and how it is merged
FPSM_Simple_Implementation.pdf   the F-PSM note (TE; for reference only)
code/                            every script; run from here
  cases.py                       THE five grating definitions (single source of truth)
  rcwa.py                        the referee: TE + TM, exact or eps-linear permittivity, complex index  (gated)
  rcwa_te.py                     the September TE referee, kept for the regression
  kogelnik.py  kogelnik_te.py    Kogelnik TE/TM, lossy; and the September TE engine kept for the regression
  fpsm.py                        F-PSM (TE lossless); raises for TM or loss -- by design
  test_fpsm_vectors.py  test_engines.py  test_tm_referee.py  test_kogelnik_pol.py   the gates
  check_env.py                   step 0 of both briefs
  compare.py                     figures + scores; --pol TM reads the *_TM Ansys tables
  summary_chart.py               the one-picture summary; --pol TM
  lumerical_rcwa.py              Lumerical driver: writes TE and TM tables from one run   ** TM UNTESTED at the solver **
  zemax_kogelnik_nsc.py          OpticStudio native-Kogelnik bench; --pol TM              ** TM UNTESTED at OpticStudio **
  zemax_rcwa_nsc.py              OpticStudio RCWA-DLL sweep; --pol TM                     ** TM sweeps UNTESTED; the switch VERIFIED 2026-09-18 **
  zos_connect.py                 standalone ZOS-API connection (install resolved by scan)
  (the remaining scripts are supporting analyses; nothing to run)
results/                         the TE tables of the September benchmark (Ansys included) and the TM referee tables
evidence/tm_reference_values.md  THE NUMBERS TO HIT (both polarisations, all five gratings)
evidence/*_gates.txt             the referee and Kogelnik gate logs from the benchmark PC
reference/                       the September verdicts, the original briefs, the Ansys article texts, the DLL probe 2
lumerical/ansys_example/         the Lumerical article's model (vhg_R_6um_model.fsp) -- do not modify
zemax/ansys_kba/                 the OpticStudio article's test_example1 and the RCWA DLL -- do not modify
```

## The five gratings (all n₀ = 1.5; `code/cases.py` is the definition)

| case | n₁ | d | λ | recording beams, in-medium | type | slant Ψ |
|---|---|---|---|---|---|---|
| `lumerical_R` (G1) | 0.04 | 6 µm | 550 nm | 0°, 28° opposite sides | reflection | 14° |
| `zemax_kba_R` (G2) | 0.05 | 5 µm | 550 nm | −45°, 0° opposite sides | reflection | 22.5° |
| `lumerical_T` (G3) | 0.04 | 6 µm | 550 nm | 0°, 28° same side | transmission | 76° |
| `unslanted_T` (G4) | 0.03 | 10 µm | 500 nm | ±33.8627° | transmission | −90° (unslanted; the DLL cannot run it) |
| `unslanted_T_rot5` (G5) | 0.03 | 10 µm | 500 nm | G4 turned 5° | transmission | −95° (the DLL substitute) |

## What TM changes, physically

The TE and TM problems share the grating; they differ in the coupling between the two principal
waves, which in TM carries the cosine of the angle between them (Kogelnik's cos 2θ_c). At Bragg on
G1 that costs 8 % of the efficiency (TE 0.804947 → TM 0.736870); in the sidelobe at 7.5° it costs
half (0.100 → 0.054); where the two waves are orthogonal the coupling vanishes. The TM referee is
Maxwell-exact (the (H, E) first-order vector formulation with the Toeplitz matrix of 1/ε), and
Kogelnik TM is the cos 2θ_c form. Both were gated on 2026-10-16 against two independent codes and
printed values (`evidence/tm_referee_gates.txt`, `evidence/kogelnik_gates.txt`).
