# EXECUTION_TM_OPTICSTUDIO.md — the OpticStudio TM (p-polarisation) leg of the F-PSM benchmark

*Written 2026-10-16 for Claude Sonnet 5.5 (Claude Code) on a PC with **Ansys Zemax OpticStudio,
Premium or Enterprise edition**, installed (2024 R1 or later). You have no other context;
everything you need is in this folder or in this file. Read the whole file before running
anything. British English throughout. This pack is a slice of a larger project; you bring results
back (`RETURN.md`), you do not rewrite the project.*

## 0. Your job in one paragraph

In September 2026 two OpticStudio legs of a volume-grating benchmark were run for **TE (s)
polarisation** on an index-matched non-sequential bench: the **native Kogelnik volume-hologram
object**, which matched the Python Kogelnik to 4×10⁻⁸, and the **RCWA hologram DLL**
(`vhg_constant_hologram230313.dll`, from Ansys knowledge-base article 42661816933139), which
matched a rigorous Python referee to 10⁻⁵ once the referee was given the DLL's own permittivity
expansion (`reference/ansys_rcwa_verdict_opticstudio.md`). The bench's source ray was TE (Jx = 1).
**Your job is to run both legs again with the source set to TM (Jy = 1), on the same gratings
with the same settings, score the tables against the TM referee and the TM Kogelnik shipped in
this pack, and write a short verdict.** The drivers already have the switch (`--pol TM`); the DLL
was shown to respond to it on 18 September (one probe, three angles, 10 layers per period), the
native object's response is unknown, and no TM sweep has ever been run.

**Rules of engagement.** (1) Every claim carries a status and a date: `VERIFIED <date>`,
`ASSUMED`, `UNTESTED`. (2) Never fabricate or tune a number; a disagreement with the referee *is*
the result. (3) Fail loudly: no silent zero; a failed run writes `*.FAILED.csv`, never overwrites a
good table. (4) Never hand-edit `.zmx`, `.zar` or any binary; change models only through the
ZOS-API. (5) Verdict first, evidence after. (6) Do not modify anything in `zemax/ansys_kba/` or
`reference/`. (7) **Confirm the licence edition before loading the DLL**: on a Professional seat
the DLL terminates OpticStudio with no error (VERIFIED 2026-09-17). Do not work around a licence.

## 1. Background — the physics (short; long form in `reference/execution_original.md` §1)

A volume holographic grating: a slab of thickness *d*, index n(**r**) = n₀ + n₁ cos(**K**·**r**),
recorded by two collimated beams **k₁**, **k₂** inside the medium at λ_r, **K** = (2πn₀/λ_r)(**k₁** − **k₂**).
Replayed near **k₁** it diffracts into **k₂** (the first order); the quantity compared is the
first-order efficiency η versus replay angle θ in the medium at fixed λ and versus λ at the Bragg
angle. Lossless, index-matched exterior, angles inside the medium.

**TE and TM on this bench.** The plane of incidence is y–z; a Source Ray tilted τ about X points
along (0, −sin τ, cos τ), so τ = −θ. Jx = 1 puts the electric field along x, perpendicular to the
plane of incidence: TE (s). Jy = 1 puts it in the plane of incidence: TM (p). In TM the coupling
between the two principal waves carries the cosine of the angle between them (Kogelnik's
cos 2θ_c), so TM efficiencies are lower at Bragg (G1: 0.805 → 0.737) and can differ by a factor of
two in the sidelobes (G1 at 7.5°: 0.100 → 0.054). The TM referee shipped here is a Maxwell-exact
vector RCWA; the TM Kogelnik is the cos 2θ_c form. Both gated 2026-10-16 (`evidence/*_gates.txt`).

The gratings (all n₀ = 1.5; `code/cases.py` is the single definition):

| case | n₁ | d | λ_r = λ | recording beams (in-medium) | type | Ψ | native Kogelnik | RCWA DLL |
|---|---|---|---|---|---|---|---|---|
| `lumerical_R` (G1) | 0.04 | 6 µm | 550 nm | 0°, 28° opposite sides | reflection | 14° | run | run (160 layers) |
| `zemax_kba_R` (G2) | 0.05 | 5 µm | 550 nm | −45°, 0° opposite sides | reflection | 22.5° | run | run (160) |
| `lumerical_T` (G3) | 0.04 | 6 µm | 550 nm | 0°, 28° same side | transmission | 76° | run | run (160) |
| `unslanted_T` (G4) | 0.03 | 10 µm | 500 nm | ±33.8627° | transmission | −90° | run | **do not run: K_z = 0 terminates OpticStudio** |
| `unslanted_T_rot5` (G5) | 0.03 | 10 µm | 500 nm | G4 turned 5° | transmission | −95° | not needed | run (320 layers) |

## 2. What is in the pack (the parts this brief uses)

```
code/cases.py                   THE grating definitions
code/rcwa.py                    the referee, TE + TM, exact / eps-linear permittivity   (gated 2026-10-16)
code/kogelnik.py                Kogelnik TE + TM (kappa cos 2 theta_c)
code/zos_connect.py             standalone (headless) ZOS-API connection; install resolved by scan or ZEMAX_ROOT
code/zemax_kogelnik_nsc.py      native-Kogelnik bench + sweep; --pol TM     TE VERIFIED 2026-09-17; TM UNTESTED
code/zemax_rcwa_nsc.py          RCWA-DLL sweep on the same bench; --pol TM  TE VERIFIED 2026-09-18 (2024 R1 Premium);
                                the TM switch VERIFIED 2026-09-18 by probe 2b; TM sweeps UNTESTED
code/compare.py                 figures + scores; --pol TM
code/summary_chart.py           the summary picture; --pol TM
code/check_env.py  test_*.py    step 0
results/zemax_<case>.csv, zemax_rcwa_<case>.csv    the September TE tables (native, DLL)
results/compare_<case>_TM_*.csv, summary_TM.csv    the TM referee and Kogelnik at every sweep point
evidence/tm_reference_values.md                    THE NUMBERS TO HIT
reference/ansys_rcwa_verdict_opticstudio.md        the September DLL verdict: every parameter, every pitfall
reference/zemax_rcwa_probe2_2026-09-18.txt         the probe that holds the one TM measurement so far
reference/execution_original.md                    the September brief (long form)
zemax/ansys_kba/test_example1/test_example1.zmx    the article's own file: the driver reads Ansys' shipped DLL
                                                   parameter values from it (never guesses them)
zemax/ansys_kba/dll/vhg_constant_hologram230313.dll   the RCWA DLL
```

## 3. What is missing

`results/zemax_<case>_TM.csv` (native Kogelnik, four cases), `results/zemax_rcwa_<case>_TM.csv`
(DLL; G1, G2, G3, G5), the TM probe printout, the regenerated TM figures and `summary_TM.csv`, and
`results/opticstudio_tm_verdict.md`. Table schema for every Ansys table: `sweep`
(`angle`|`wavelength`), `source_tilt_x_deg` (**= −θ**), `lambda_um`, `P_entry_side_W` (reflected
first order per 1 W), `P_far_side_W` (transmitted first order), then the driver's extra columns.

## 4. Environment

Windows. Python ≥ 3.10 with `numpy`, `matplotlib`, `pythonnet`. OpticStudio is found by
`zos_connect.py`: the environment variable `ZEMAX_ROOT` (the *install* folder holding
`ZOSAPI.dll`), else the highest-named `C:\Program Files\*Zemax OpticStudio*`. The DLL must sit in
`<ZemaxDataDir>\DLL\Diffractive\` (the *data* folder, normally `Documents\Zemax`; the driver
prints `app.ZemaxDataDir`). Connection is standalone (headless). Run every script from `code/`.
Print with `flush=True` and redirect long runs to a log.

**Licence check first:**
```
python -c "import sys; sys.path.insert(0,'.'); from zos_connect import Zos; z=Zos(); a=z.app; print(a.ZOSMajorVersion, a.ZOSMinorVersion, a.LicenseStatus, a.ZemaxDataDir); z.close(); import os; os._exit(0)"
```
The status must read PremiumEdition or EnterpriseEdition before step 2. ProfessionalEdition: do
step 1 only, and say so.

## 5. Procedure

**Step 0 — prove the pack on this machine (15 min).**
`python check_env.py opticstudio` → `READY`.
`python test_fpsm_vectors.py` → `0 failure(s)`. `python test_engines.py` → `0 failure(s)` (a SKIP
line about `PSMGRATING_PATH` is expected). `python test_tm_referee.py` and
`python test_kogelnik_pol.py` → `0 failure(s)` each; gates G3, G4 and K3 report **SKIP** here
(their oracles live on the benchmark PC) — expected.
`python compare.py lumerical_R` → the printed row's `python_rcwa_epslin_vs_zemax_rcwa_rms` is
2.95×10⁻⁵ (3 s.f.): the TE referee, the scoring and the reference tables are intact.
Then the September TE bench, to prove ZOS-API and the licence on *this* install:
`python zemax_kogelnik_nsc.py lumerical_R` (~5 min, writes `results/zemax_lumerical_R.csv`), then
`python compare.py lumerical_R`: column `zemax_native_vs_my_kogelnik_max` ≤ 10⁻⁶.

**Step 1 — native Kogelnik, TM (25 min).** `python zemax_kogelnik_nsc.py lumerical_R --pol TM`
→ `results/zemax_lumerical_R_TM.csv`, `zemax/kogelnik_native_lumerical_R_TM.zmx`. Then
`python compare.py --pol TM lumerical_R` and read `zemax_native_vs_my_kogelnik_max` in
`results/summary_TM.csv`. Two outcomes, both findings (gate **N1**):
- ≤ 10⁻⁶: OpticStudio's native model applies Kogelnik's TM factor (κ cos 2θ_c).
- of order 10⁻² or more: compare the new table with the TE one (`results/zemax_lumerical_R.csv`):
  if identical, the native model ignores polarisation (its article's table says "polarisation:
  approximation"); if neither, say what it is — e.g. recompute the ratio TM/TE at Bragg and at
  7.5° and compare with 0.9154 and 0.5363 (referee) and 0.9154 / 0.5863 (Kogelnik).
Run the other three (`zemax_kba_R`, `lumerical_T`, `unslanted_T`) the same way; the outcome must
be the same on all four.

**Step 2 — DLL TM probe (20 min; Premium/Enterprise only).** Install the DLL if absent (copy it
into `<ZemaxDataDir>\DLL\Diffractive\`). Then
`python zemax_rcwa_nsc.py --pol TM --probe lumerical_R > ../results/zemax_rcwa_probe_TM.txt`.
It prints every DLL parameter (gate Z1 of the September brief: 24 names, shipped values as in
`reference/ansys_rcwa_verdict_opticstudio.md`), the Bragg order, the energy sum over orders
−3…3, the harmonic ladder (Max Order 3/5/9/13) and the layer ladder, now 10/20/40/80/160/320, at
θ = 0°, −14°, 7.5°, and the DLL log tail. Gates **D0–D2** (§6).

**Step 3 — DLL TM sweeps (about 1 h).** `python zemax_rcwa_nsc.py --pol TM <case>` for
`lumerical_R`, `zemax_kba_R`, `lumerical_T` (160 layers per period, the default) and
`python zemax_rcwa_nsc.py --pol TM unslanted_T_rot5 --layers 320` → `results/zemax_rcwa_<case>_TM.csv`,
`zemax/rcwa_dll_<case>_TM.zmx`. **Do not run `unslanted_T` on the DLL** (K_z = 0 terminates the
server; VERIFIED 2026-09-18). For `lumerical_T` the driver traces both integer orders and applies
the K·k labelling rule; keep its printout.

**Step 4 — overlay and score (5 min).** `python compare.py --pol TM` (all cases) and
`python summary_chart.py --pol TM`. Circles: native Kogelnik; squares: the DLL; lower panels: the
deviation from the exact TM referee (dotted) and from the ε-linear TM referee (dashed). Gates
**D3**. **Look at every figure before calling it done.**

**Step 5 — write up.** `results/opticstudio_tm_verdict.md`: verdict first, in bold; the N1 finding
with its numbers; a table case × sweep with DLL-vs-exact-TM-referee rms and max, DLL-vs-ε-linear
rms and max, Kogelnik-TM-vs-DLL rms; the TM convergence ladder; the DLL's TM behaviour near the
cut-off of `zemax_kba_R` (θ = 16.8–17.0°) and at the 3.5° Rayleigh anomaly of `lumerical_R`;
every deviation from this procedure; OpticStudio version and licence edition; what remains
UNTESTED. Then follow `RETURN.md`.

## 6. Acceptance gates — how you know it is right

Reference values (converged Python referee, L = 14; per 1 W incident; R+1 / T+1 the first order on
the entry / far face). Full table: `evidence/tm_reference_values.md`.

| case | θ (°) | λ (nm) | TE referee | **TM referee, exact** | **TM referee, ε-linear** (the DLL's form) | Kogelnik TM |
|---|---|---|---|---|---|---|
| `lumerical_R` | 0 and −28 (Bragg) | 550 | 0.804947 | **0.736870** | **0.736918** | 0.737264 |
| `lumerical_R` | −14 | 550 | 0.023944 | **0.023919** | **0.027389** | 0.014014 |
| `lumerical_R` | 7.5 | 550 | 0.100148 | **0.053714** | **0.053529** | 0.049672 |
| `lumerical_T` | 0 (Bragg) | 550 | 0.978518 | **0.916206** | **0.916025** | 0.922215 |
| `lumerical_T` | 5 | 550 | 0.013852 | **0.021129** | **0.020901** | 0.029352 |
| `zemax_kba_R` | −45 and 0 (Bragg) | 550 | 0.873784 | **0.694665** | **0.694597** | 0.695385 |
| `zemax_kba_R` | −22.5 | 550 | 0.012827 | **0.012825** | **0.011817** | 0.042365 |

What the DLL gave on 18 September at **10 layers per period** (unconverged by about 1 %), TM
against TE, on `lumerical_R`:

| θ (°) | DLL TE | DLL TM | TM/TE DLL | TM/TE referee (ε-linear) |
|---|---|---|---|---|
| 0 | 0.7965196 | 0.7272546 | 0.9130 | 0.9154 |
| −14 | 0.0245959 | 0.0245981 | 1.0001 | 0.9990 |
| 7.5 | 0.0978717 | 0.0520480 | 0.5318 | 0.5332 |

- **N1** (step 1): as described there; the same outcome on all four cases.
- **D0** (step 2, reproducibility): the TM values at 10 layers per period reproduce the September
  ones above to 10⁻⁶ (same DLL, same bench, same grating). *Else:* the bench or the polarisation
  switch differs — check Jx/Jy, `UsePolarization`, Split NSC Rays ON, StartOrder = StopOrder.
- **D1** (step 2, convergence): the TM layer ladder converges as 1/N² (successive differences
  falling by factors of about 4) and Max Order 3/5/9/13 agree to 10⁻⁶; the converged TM Bragg value
  on G1 sits within 10⁻⁴ of the **ε-linear** TM referee 0.736918 (TE did: 0.805024 against
  0.805032). Energy over orders −3…3 = 1.000 ± 10⁻³ with `Only these orders` = 0.
- **D2** (step 2, the discriminating point): at θ = −14° the converged DLL TM value lands near
  0.0274 (ε-linear), not 0.0239 (exact) and not 0.0140 (Kogelnik) — the same definitional
  difference as in TE. If it lands on 0.0239 instead, the DLL's permittivity expansion is
  polarisation-dependent; that would be a new finding — report it with the numbers.
- **D3** (step 4): in `summary_TM.csv`, `python_rcwa_epslin_vs_zemax_rcwa_rms` ≤ 10⁻⁴ on every
  sweep (TE: 1–6×10⁻⁵, excluding the single point within 0.1° of G2's cut-off), while
  `python_rcwa_vs_zemax_rcwa_rms` is 10⁻³ to 10⁻² (the n₁² terms). Report both, and whether the gap
  between the two forms is larger in TM than in TE (the reference table says it is the same size
  at −14°: 3.5×10⁻³).
- **If a gate cannot be met,** do not loosen it silently: report the measured value, your
  diagnosis, and mark the affected table `UNTESTED` or `FAILED`.

## 7. Pitfalls already paid for (VERIFIED 2026-09-17/18 unless marked)

- **Licence.** The DLL needs Premium/Enterprise; on Professional it closes OpticStudio silently.
  Check `app.LicenseStatus` first.
- **Polarisation on the bench.** Source Ray `Jx = 1, Jy = 0` is TE, `Jx = 0, Jy = 1` is TM for the
  y–z plane of incidence; `UsePolarization = True` on the trace; `RandomPolarization = False`.
  Probe 2b also recorded "random polarisation" = 0.7669 at Bragg, between TE and TM, as expected.
- **DLL settings that the shipped example gets wrong:** `Only these orders` = 16 is an order filter
  (set 0); `Layer per period` = 10 is 8.5×10⁻³ low (use 160; 320 for G5); `Interpolation` is an
  angular lookup-grid size (leave 0; 16001 terminates OpticStudio at wavelength changes). The driver
  applies these; do not change them.
- **The DLL's permittivity expansion**: ε = n₀² + 2n₀n₁cos(**K**·**r**), no n₁² terms. The referee
  with `eps_form="linear"` reproduces it to 10⁻⁵ in TE. `compare.py` scores against both forms.
- **K_z = 0 terminates the server** (`unslanted_T`); slabs thinner than one z-period return wrong
  values silently (rotations of 0.01–1°); G5 at 5° (2.9 periods) is the substitute.
- **Near a first-order cut-off** (`zemax_kba_R`, θ = 16.8–17.0°) the DLL departed from both referee
  forms in TE (0.002 against 0.045 at 17.0°). Watch the same points in TM; report them separately.
- **Thickness units differ by object**: native `Hologram Thickness` is in lens units (mm); the
  DLL's `Holo Thic (um)` is micrometres. The drivers handle both; do not edit.
- **NSC minimum relative ray intensity** must be lowered (the bench sets 10⁻¹²) or every sidelobe
  below 10⁻³ reads zero.
- **Order labelling**: the native model traces as "order 1" the order with **K**·**k** > 0; on
  `lumerical_T` the label swaps past θ = 14°; the DLL traces fixed integer orders and the driver
  stitches by the same rule, keeping both raw orders in the table.
- **pythonnet + ZOS-API hangs at interpreter exit**: the scripts end with `os._exit`. Print with
  `flush=True`. `*** FRU__delta_init(): Attempt to start when running!` on stdout is harmless.
  Do not call `DiffractionData.GetAvailableDLLs()` (hung a headless session once).
- Each DLL evaluation takes about 1.5 s at 160 layers per period; a sweep pair is 5–15 min.

## 8. Deliverables checklist

- [ ] step 0: `READY`; `0 failure(s)` ×4 (with the expected SKIPs); `compare.py lumerical_R` reproduces 2.95×10⁻⁵; native TE agreement ≤ 10⁻⁶ on this PC; the licence edition recorded
- [ ] `results/zemax_<case>_TM.csv` ×4 and `zemax/kogelnik_native_<case>_TM.zmx`; the N1 finding stated with numbers
- [ ] `results/zemax_rcwa_probe_TM.txt` with gates D0–D2 evaluated
- [ ] `results/zemax_rcwa_{lumerical_R,zemax_kba_R,lumerical_T,unslanted_T_rot5}_TM.csv` and `zemax/rcwa_dll_*_TM.zmx`
- [ ] regenerated `figures/compare_<case>_TM.png` and `figures/summary_rms_TM.png`; `results/summary_TM.csv` with the OpticStudio columns filled
- [ ] `results/opticstudio_tm_verdict.md`
- [ ] the final `code/zemax_rcwa_nsc.py` and `code/zemax_kogelnik_nsc.py`

Finish with a short report: verdict; the N1 finding; the DLL TM agreement numbers against both
referee forms; what you changed in the drivers and why; what is still untested. If something is
blocked by a licence, an access control or a missing product, say exactly what and stop there.
