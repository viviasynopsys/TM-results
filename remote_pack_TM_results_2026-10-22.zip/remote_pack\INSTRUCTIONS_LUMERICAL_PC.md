# Instructions for Claude (Sonnet 5.5) on the Lumerical PC — TM leg of the F-PSM grating benchmark

*For the person at the keyboard: extract the pack (`remote_pack_TM_2026-10-16.7z`, `.zip` or `_gmail.zip`)
into a folder of its own, copy this file into the extracted `remote_pack` folder next to `CLAUDE.md`,
open Claude Code in that folder and type: **"Follow INSTRUCTIONS_LUMERICAL_PC.md exactly, step by step,
and give me the report it asks for at the end."** Nothing else is needed from you until it finishes
(about 90 minutes of solver time). Written 2026-10-16. British English.*

---

## What you are doing

Five volume holographic gratings were benchmarked in September 2026 for TE (s) polarisation with
Lumerical's RCWA solver, through the driver `code/lumerical_rcwa.py`, and the solver matched an
independent Python referee to between 10⁻¹² and 4 × 10⁻⁵. Lumerical solves s and p together but only
the s results were recorded. **Re-run the five gratings with the updated driver, which now also
records the p (TM) results, and score them against the TM referee that is in this pack.** You are
measuring, not modelling: never tune a number, never invent one, never continue past a failed gate
as if it had passed. Every sentence you write carries `VERIFIED <date>`, `ASSUMED` or `UNTESTED`.

The five gratings are defined once, in `code/cases.py`: `lumerical_R`, `zemax_kba_R`, `lumerical_T`,
`unslanted_T`, `unslanted_T_rot5`. All have n₀ = 1.5. Reflection gratings read the first order on the
entry face (R+1), transmission gratings on the far face (T+1). Efficiencies are fractions of the
incident power. Angles are inside the medium.

## Before you start

1. You need: Windows (not WSL), Python 3.10 or later with `numpy` and `matplotlib`, Ansys Lumerical
   2025 R1 or later with the RCWA solver licensed, and `lumapi.py` (ships under
   `<Lumerical install>\api\python\`). If the driver cannot find `lumapi.py`, set the environment
   variable `LUMAPI_PATH` to its full path. Never hard-code an install path in the code.
2. Work from inside `code\`. Every command below is run there.
3. Do not modify anything in `lumerical\ansys_example\`, `reference\`, or `evidence\`.
4. Do not hand-edit `.fsp` files; the driver changes the model through `lumapi` only.
5. Long sweeps (141–201 angles) can take tens of minutes; run them in the background and watch the log.
6. If a licence dialog or an RCWA-licence error appears: stop, report it word for word, do not work around it.

## Step 0 — prove the pack on this machine (10 minutes)

Run, and check each result before moving on:

| command | must print | if not |
|---|---|---|
| `python check_env.py lumerical` | `READY` | fix what it names (usually `LUMAPI_PATH`) |
| `python test_fpsm_vectors.py` | `0 failure(s)` | stop; the pack is damaged |
| `python test_engines.py` | `0 failure(s)` (one `SKIP … PSMGRATING_PATH` line is normal) | stop; the pack is damaged |
| `python test_tm_referee.py` | `0 failure(s)`; `SKIP` for G3 and G4 is normal here | stop; the pack is damaged |
| `python test_kogelnik_pol.py` | `0 failure(s)`; `SKIP` for K3 is normal | stop; the pack is damaged |
| `python compare.py lumerical_R` | a row whose column `python_rcwa_epslin_vs_zemax_rcwa_rms` is `2.95e-05` | stop; the reference tables are not intact |
| `python compare.py --pol TM lumerical_R` | runs; two lines saying no `…_TM.csv` yet | stop and report |

## Step 1 — probe the solver (5 minutes)

`python lumerical_rcwa.py --probe lumerical_R`

It writes `results\lumerical_probe.txt`: every property of the model, the RCWA object and the
rectangle with its value, and every result dataset. Open it and confirm that the dataset
`grating_power` has attributes `Rs_power`, `Ts_power`, **`Rp_power`, `Tp_power`** with the same
shape, and that `total_energy` has `Rs`, `Ts`, **`Rp`, `Tp`**. If a name differs on this build,
correct the four entries `res_Rp`, `res_Tp`, `res_energy_Rp`, `res_energy_Tp` in the NAME MAP `P`
near the top of `lumerical_rcwa.py`, and write down what you changed and why.

## Step 2 — one solve at Bragg (5 minutes)

`python lumerical_rcwa.py --bragg lumerical_R`

Shipped settings (10 layers per period). It prints the TE and TM efficiency of every order at the
Bragg angle, the energy sums and the referee values. Gates:

- TE peak ≈ 0.796 in one order (the 10-layer value; the converged value is 0.805); energy sum
  R + T = 1.000 ± 0.001; simulated thickness 6.000 µm.
- **TM peak in the same order index as the TE peak**; TM energy sum = 1.000 ± 0.001;
  **TM/TE ratio at Bragg = 0.915 ± 0.005** (the referee's ratio is 0.9154; the layer error cancels
  in the ratio).

If the TM peak equals the TE peak to three decimals, you are reading the s attribute under another
name: go back to step 1.

## Step 3 — convergence (20 minutes)

`python lumerical_rcwa.py --converge lumerical_R`

Writes `results\lumerical_converge_lumerical_R.txt`: rungs in harmonics (3/5/9/13) and in layers per
period (10/20/40/80/160) at θ = 0°, −14°, 7.5°, each rung with TE values and, after `TM:`, TM values.
Gates: harmonics 3 = 5 = 9 = 13 to 10⁻⁶; the layer ladder converges from below as 1/N² (differences
falling by about 4 each rung); **at 160 layers TM at Bragg ≈ 0.7368 ± 0.0001** (referee 0.736870).
Keep 3 harmonics and 160 layers unless the TM ladder says otherwise, and say so if it does.

## Step 4 — the five sweeps (about an hour)

Run, in this order:

```
python lumerical_rcwa.py lumerical_R      --harmonics 3 --layers 160
python lumerical_rcwa.py zemax_kba_R      --harmonics 3 --layers 160
python lumerical_rcwa.py lumerical_T      --harmonics 3 --layers 160
python lumerical_rcwa.py unslanted_T      --harmonics 3 --layers 160
python lumerical_rcwa.py unslanted_T_rot5 --harmonics 3 --layers 160
```

Each run writes **two** tables, `results\lumerical_rcwa_<case>.csv` (TE) and
`results\lumerical_rcwa_<case>_TM.csv` (TM), and saves `lumerical\rcwa_<case>.fsp`. Each prints two
preview lines, TE and TM, "angle sweep vs referee: exact rms …". Expect about 3 × 10⁻⁵ for TE on
`lumerical_R` and the same order of magnitude for TM. Notes:

- `lumerical_T`: past θ = 14° the "first order" is the conjugate integer order; the driver decides
  the order and the sign of θ on the TE curve and applies the same choice to TM. Keep its printout.
- `unslanted_T`: K_z = 0; the driver bypasses the model's setup script and writes the index equation
  itself. Do not rotate the grating instead.
- A failed run writes `*.FAILED.csv` and never overwrites a good table. Report it; do not retry blindly.

## Step 5 — score (5 minutes)

```
python compare.py --pol TM
python summary_chart.py --pol TM
python compare.py
```

The first two draw the TM tables as triangles on `figures\compare_<case>_TM.png` and fill
`results\summary_TM.csv`. The third rescores the re-run TE tables into `results\summary.csv`.
Look at every figure before calling it done.

## The numbers that decide whether it worked

Converged Python referee, per 1 W incident. Full table: `evidence\tm_reference_values.md`.

| grating | θ (°) | λ (nm) | TE referee | **TM referee** | TM, ε-linear | Kogelnik TM |
|---|---|---|---|---|---|---|
| `lumerical_R` | 0 and −28 (Bragg) | 550 | 0.804947 | **0.736870** | 0.736918 | 0.737264 |
| `lumerical_R` | −14 | 550 | 0.023944 | **0.023919** | 0.027389 | 0.014014 |
| `lumerical_R` | 7.5 | 550 | 0.100148 | **0.053714** | 0.053529 | 0.049672 |
| `lumerical_T` | 0 (Bragg) | 550 | 0.978518 | **0.916206** | 0.916025 | 0.922215 |
| `lumerical_T` | 5 | 550 | 0.013852 | **0.021129** | 0.020901 | 0.029352 |
| `zemax_kba_R` | −45 and 0 (Bragg) | 550 | 0.873784 | **0.694665** | 0.694597 | 0.695385 |
| `zemax_kba_R` | −22.5 | 550 | 0.012827 | **0.012825** | 0.011817 | 0.042365 |
| `unslanted_T` | 33.8627 (Bragg) | 500 | 0.586035 | **0.575192** | 0.575276 | 0.574755 |
| `unslanted_T` | 36 | 500 | 0.243709 | **0.025373** | 0.025397 | 0.019329 |
| `unslanted_T_rot5` | 38.8627 (Bragg) | 500 | 0.573615 | **0.579853** | 0.579934 | 0.579477 |
| `unslanted_T_rot5` | 41 | 500 | 0.243315 | **0.018743** | 0.018821 | 0.014794 |

Gates on `results\summary_TM.csv`:

- **T1**: `python_rcwa_vs_lumerical_rcwa_rms` ≤ 10⁻³ on every case; expected 10⁻⁵ to 4 × 10⁻⁵ on the
  slanted gratings and about 10⁻¹² on `unslanted_T`; and smaller than
  `python_rcwa_epslin_vs_lumerical_rcwa_rms` (in TE Lumerical sat on the exact form, 30–100× nearer
  than the ε-linear one). Report which form TM follows.
- **R0** (on `results\summary.csv`, TE): the re-run TE tables agree with the September ones to rms
  ≤ 10⁻⁶ per sweep (the September scores are in `reference\summary_2026-09-30.csv`).
- The off-Bragg rows discriminate: at θ = −14° on `lumerical_R` a genuine TM RCWA gives 0.0239
  (exact) or 0.0274 (ε-linear), never 0.0140 (Kogelnik); at 7.5° TM is half of TE.

If a gate fails: report the measured value and your diagnosis, mark the table `UNTESTED` or
`FAILED`, and do not loosen the gate.

## Step 6 — optional, only if steps 0–5 passed (10 minutes at most)

`python lumerical_rcwa.py --bragg lumerical_R --chi0 1e-3 --harmonics 3 --layers 160`

An experiment: the driver appends `-0.001i` to the rectangle's index equation (n = 1.5 − 0.001i +
0.04 cos). Whether Lumerical accepts a complex spatial index is UNTESTED. Pass: energy sums fall to
≈ 0.9156 (TE) and ≈ 0.9094 (TM), first order ≈ 0.7360 (TE) / 0.6688 (TM), within 2 × 10⁻³. If the
driver raises "imaginary index was ignored", record that and stop; do not build a material by hand.

## Step 7 — write the verdict and return

Write `results\lumerical_tm_verdict.md`: the verdict first, in bold; a table case × sweep with
TM-referee-vs-Lumerical rms and max, Kogelnik-TM-vs-Lumerical rms and the ε-linear column; which
ε form TM follows; the R0 numbers; converged settings; every name or assumption you changed and the
evidence; Lumerical version and licence edition; what remains UNTESTED.

Then zip the whole `remote_pack` folder and hand it back. It must contain: the ten
`results\lumerical_rcwa_*.csv` tables, `results\lumerical_probe.txt`,
`results\lumerical_converge_lumerical_R.txt`, `lumerical\rcwa_*.fsp`, `results\summary_TM.csv`,
`results\summary.csv`, the regenerated figures, `results\lumerical_tm_verdict.md`, and the final
`code\lumerical_rcwa.py`. Do not rename files or change the CSV columns.

Finish with a short report in the chat: verdict; the T1 and R0 numbers; which ε form TM follows;
what you changed in the driver and why; what is still untested.

## Pitfalls already paid for (so you do not pay again)

- There is no polarisation property; s and p are always both solved. TE = `Rs_power`/`Ts_power`,
  TM = `Rp_power`/`Tp_power`.
- Thickness is the RCWA object's layer repetition, not a model property; the setup script re-runs at
  every solve and restores geometry it owns; the driver reads the real thickness back and refuses on
  a mismatch.
- Layers per period = the `interface reference positions` count (shipped 10; use 160).
- `Dn` is the cosine amplitude (0.04), not peak-to-peak.
- Lumerical's θ sign is fitted by the driver, never assumed (it was +1 on all cases in September).
- The 2026-09-18 probe dump was truncated by numpy's print threshold; the driver now prints arrays in full.
- Ansys knowledge-base pages return HTTP 403 to plain fetches; the three relevant articles are in
  `reference\` as text.
