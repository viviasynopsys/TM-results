# Lumerical TM leg — verdict (2026-10-22)

**Verdict: PASS. Lumerical's RCWA solver reproduces the exact-permittivity Python TM referee to 1 × 10⁻⁵ – 4 × 10⁻⁵ rms on the four slanted gratings and to 10⁻¹¹ on `unslanted_T`. Gate T1 passes on all ten sweeps, gate R0 passes (TE re-run identical to September to ≤ 10⁻¹³), and TM follows the *exact* ε form (n₀ + n₁cos)², not the ε-linear one. The optional complex-index experiment (step 6) did not work: Lumerical ignored the imaginary index.** VERIFIED 2026-10-22.

Machine: Windows; Python 3.13.14 (numpy 2.5.1, matplotlib 3.11.1); Ansys Lumerical v261 (`lumapi` reports version 8.35.4609), `LUMAPI_PATH` set to `C:\Program Files\Ansys Inc\v261\Lumerical\api\python\lumapi.py`. Licence edition: UNTESTED (not queried; the RCWA solver ran, so it is licensed).

## Step 0 – pack proof (VERIFIED 2026-10-22)
`check_env.py lumerical` READY; `test_fpsm_vectors` 0 failures; `test_engines` 0 failures (explorer SKIP); `test_tm_referee` 0 failures (G3, G4 skipped); `test_kogelnik_pol` 0 failures (K3 skipped); `compare.py lumerical_R` gives `python_rcwa_epslin_vs_zemax_rcwa_rms` = 2.95e-05; `compare.py --pol TM lumerical_R` ran with the two "no …_TM.csv" notices.

## Step 1 – probe (VERIFIED 2026-10-22)
`grating_power` has `Rs_power, Ts_power, Rp_power, Tp_power` (shape 1×81×7×1×2); `total_energy` has `Rs, Ts, Rp, Tp`. The NAME MAP in `lumerical_rcwa.py` needed no change. The 79 `FAILED` lines in `results\lumerical_probe.txt` are the probe's `getnamed` attempts on the `::model` object, which holds none of those properties; they are not errors in the driver.

## Step 2 – Bragg at 10 layers (VERIFIED 2026-10-22)
TE peak 0.796427 (order +1); R+T = 1.000000; thickness 6.0000 µm. TM peak 0.727200 in the same order; TM R+T = 1.000000; TM/TE = 0.9131 (gate 0.915 ± 0.005; the referee's ratio is 0.9154). TM differs from TE, so the p attributes are genuinely read.

## Step 3 – convergence of `lumerical_R` (VERIFIED 2026-10-22)
| rung | TE θ = 0° | TM θ = 0° | TM θ = −14° | TM θ = 7.5° |
|---|---|---|---|---|
| harmonics 3 / 5 / 9 / 13 (80 layers) | 0.804816 | 0.73672 | 0.023878 | 0.05369 |
| 10 layers | 0.796427 | 0.727200 | 0.021415 | 0.052136 |
| 20 layers | 0.80284 | 0.734471 | 0.023271 | 0.053307 |
| 40 layers | 0.804422 | 0.736271 | 0.023756 | 0.05361 |
| 80 layers | 0.804816 | 0.73672 | 0.023878 | 0.05369 |
| 160 layers | 0.804914 | **0.736832** | 0.023909 | 0.053708 |
| TM referee, exact / ε-linear | | 0.736870 / 0.736918 | 0.023919 / 0.027389 | 0.053714 / 0.053529 |

Harmonics 3 = 5 = 9 = 13 exactly. The TM layer ladder at Bragg falls by 7.27e-3, 1.80e-3, 4.49e-4, 1.12e-4 (ratio ≈ 4.0 per rung, 1/N²). TM at 160 layers = 0.736832, within 4 × 10⁻⁵ of the referee (gate ± 1 × 10⁻⁴). Settings kept: 3 harmonics, 160 layers.

## Step 4 – sweeps (VERIFIED 2026-10-22)
Run as `--harmonics 3 --layers 160`; every run had R+T = 1.000000 for TE and TM, thickness read back equal to the request, theta sign +1 and Bragg order as in September (`lumerical_T`: +1; `unslanted_T` and `unslanted_T_rot5`: −1). No `*.FAILED.csv` was written. `unslanted_T` used the driver's index-equation bypass (dx = 0.299112 µm, rectangle z span 10 µm, repetition off).

## Gate T1 – TM referee vs Lumerical (from `results\summary_TM.csv`)
| case | sweep | TM exact referee vs Lumerical rms | max | ε-linear referee vs Lumerical rms | Kogelnik-TM vs Lumerical rms |
|---|---|---|---|---|---|
| `lumerical_R` | angle | 2.79e-05 | 5.65e-05 | 3.95e-03 | 7.01e-03 |
| `lumerical_R` | wavelength | 1.66e-05 | 5.40e-05 | 2.13e-03 | 8.40e-03 |
| `zemax_kba_R` | angle | 1.91e-05 | 5.22e-05 | 3.59e-03 | 1.56e-02 |
| `zemax_kba_R` | wavelength | 1.94e-05 | 4.91e-05 | 3.57e-03 | 1.04e-02 |
| `lumerical_T` | angle | 1.53e-05 | 4.75e-05 | 4.30e-04 | 1.57e-02 |
| `lumerical_T` | wavelength | 3.54e-05 | 5.44e-05 | 5.17e-04 | 1.96e-02 |
| `unslanted_T` | angle | 9.52e-12 | 3.72e-11 | 2.06e-05 | 8.62e-03 |
| `unslanted_T` | wavelength | 1.09e-11 | 3.96e-11 | 2.53e-05 | 9.82e-03 |
| `unslanted_T_rot5` | angle | 1.33e-05 | 5.62e-05 | 1.25e-04 | 8.63e-03 |
| `unslanted_T_rot5` | wavelength | 1.54e-05 | 5.67e-05 | 1.46e-04 | 9.89e-03 |

All ten are ≤ 10⁻³ (largest 3.5 × 10⁻⁵), and in every sweep the exact referee is nearer than the ε-linear one (by factors of about 9 to 10⁶). **TM follows the exact form**, as TE did. T1: PASS. Off-Bragg discriminators on `lumerical_R` at 160 layers: TM at −14° = 0.023909 (exact 0.023919, ε-linear 0.027389, Kogelnik 0.014014); TM at 7.5° = 0.053708 against TE 0.100138 (about half).

## Gate R0 – TE re-run vs September (VERIFIED 2026-10-22)
Compared `P_entry_side_W` and `P_far_side_W` point by point against the September tables in `..\results\`:

| case | rms entry | rms far | max (either) |
|---|---|---|---|
| `lumerical_R` | 1.7e-14 | 1.0e-16 | 8.2e-14 |
| `zemax_kba_R` | 1.1e-14 | 1.2e-16 | 5.9e-14 |
| `lumerical_T` | 3.1e-17 | 4.4e-15 | 1.8e-14 |
| `unslanted_T` | 1.1e-17 | 1.0e-14 | 5.2e-14 |
| `unslanted_T_rot5` | 4.2e-17 | 3.4e-15 | 1.9e-14 |

R0 (≤ 10⁻⁶): PASS. The regenerated TE scores in `results\summary.csv` agree with `reference\summary_2026-09-30.csv` in every Lumerical column; the only differences are in the fourth figure of the ~10⁻¹² `unslanted_T` rows (for example 1.098e-12 against 1.092e-12), which is floating-point noise.

## Step 6 – complex index, optional (VERIFIED 2026-10-22: it did not work)
`lumerical_rcwa.py --bragg lumerical_R --chi0 1e-3 --harmonics 3 --layers 160` solved with TE 0.804914 and TM 0.736832, identical to the lossless run, energy sums 1.000000, and the driver raised "absorption probe: energy sum 1.000000 is still 1 -- the imaginary index was ignored". Lumerical's RCWA solver therefore ignores a complex spatial index equation on this build. Stopped as instructed; no material was built by hand.

## Figures
Looked at `figures\compare_<case>_TM.png` for all five cases and `figures\summary_rms_TM.png`: the triangles sit on the rigorous TM curve, the TE curve (grey dashed) is visibly different, and the Lumerical-minus-RCWA difference stays at or below 10⁻⁴ everywhere. The summary chart's subtitle still says "Ansys TM tables appear here when the remote runs return"; that is the script's fixed wording, not an error.

## Changes to the driver
None. `code\lumerical_rcwa.py` is the shipped file; no name or assumption was changed. The only environment changes were setting `LUMAPI_PATH` for the session and, for the OpticStudio leg, installing `pythonnet` and setting `ZEMAX_ROOT`.

## UNTESTED
Lumerical licence edition; a complex spatial index (step 6 failed); the OpticStudio leg is in `results\opticstudio_tm_verdict.md`.
