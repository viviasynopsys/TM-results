# Instructions for Claude (Sonnet 5.5) on the OpticStudio PC — TM leg of the F-PSM grating benchmark

*For the person at the keyboard: extract the pack (`remote_pack_TM_2026-10-16.7z`, `.zip` or `_gmail.zip`)
into a folder of its own, copy this file into the extracted `remote_pack` folder next to `CLAUDE.md`,
open Claude Code in that folder and type: **"Follow INSTRUCTIONS_OPTICSTUDIO_PC.md exactly, step by
step, and give me the report it asks for at the end."** The seat must be Premium or Enterprise for
steps 2–3; Professional can do step 1 only. If the pack came by e-mail (`_gmail.zip`) the RCWA DLL is
missing and `zemax\ansys_kba\dll\README_DLL_REMOVED.md` says where to get it. About two hours of
machine time. Written 2026-10-16. British English.*

---

## What you are doing

Five volume holographic gratings were benchmarked in September 2026 for TE (s) polarisation on an
index-matched non-sequential OpticStudio bench, with two legs: the **native Kogelnik volume-hologram
object**, which matched the Python Kogelnik to 4 × 10⁻⁸, and the **RCWA hologram DLL**
(`vhg_constant_hologram230313.dll` from Ansys article 42661816933139), which matched a rigorous
Python referee to 10⁻⁵ once the referee used the DLL's own permittivity expansion. The bench's source
ray was TE (Jx = 1). **Run both legs again with the source set to TM (Jy = 1), same gratings, same
settings, and score them against the TM referee and the TM Kogelnik that are in this pack.** You are
measuring, not modelling: never tune a number, never invent one, never continue past a failed gate as
if it had passed. Every sentence you write carries `VERIFIED <date>`, `ASSUMED` or `UNTESTED`.

The gratings are defined once, in `code\cases.py`:

| case | type | native Kogelnik, TM | RCWA DLL, TM |
|---|---|---|---|
| `lumerical_R` | reflection | run | run (160 layers per period) |
| `zemax_kba_R` | reflection | run | run (160) |
| `lumerical_T` | transmission | run | run (160) |
| `unslanted_T` | transmission, unslanted | run | **never: K_z = 0 terminates OpticStudio** |
| `unslanted_T_rot5` | transmission | not needed | run (320) |

## Before you start

1. You need: Windows, Python 3.10 or later with `numpy`, `matplotlib`, `pythonnet`; OpticStudio
   2024 R1 or later. The scripts find the install through the environment variable `ZEMAX_ROOT`
   (the install folder holding `ZOSAPI.dll`) or by scanning `C:\Program Files\*Zemax OpticStudio*`.
   Never hard-code a path.
2. Work from inside `code\`. Every command below is run there. Connection is standalone (headless).
3. Do not modify anything in `zemax\ansys_kba\`, `reference\` or `evidence\`. Never hand-edit a
   `.zmx` or `.zar`; the scripts write benches through the ZOS-API.
4. The scripts end with `os._exit` because pythonnet hangs at interpreter exit; that is normal.
   `*** FRU__delta_init(): Attempt to start when running!` on stdout is harmless.
5. **Licence first.** Run
   `python -c "import sys; sys.path.insert(0,'.'); from zos_connect import Zos; z=Zos(); a=z.app; print(a.ZOSMajorVersion, a.ZOSMinorVersion, a.LicenseStatus, a.ZemaxDataDir); z.close(); import os; os._exit(0)"`
   and record the output. `PremiumEdition` or `EnterpriseEdition`: all steps. `ProfessionalEdition`:
   step 1 only, then stop and say so. The DLL terminates OpticStudio silently on a Professional seat.
   Any other status (for example `KeyNotWorking`): stop and report it.

## Step 0 — prove the pack on this machine (15 minutes)

| command | must print | if not |
|---|---|---|
| `python check_env.py opticstudio` | `READY` | fix what it names |
| `python test_fpsm_vectors.py` | `0 failure(s)` | stop; the pack is damaged |
| `python test_engines.py` | `0 failure(s)` (one `SKIP … PSMGRATING_PATH` line is normal) | stop |
| `python test_tm_referee.py` | `0 failure(s)`; `SKIP` for G3 and G4 is normal here | stop |
| `python test_kogelnik_pol.py` | `0 failure(s)`; `SKIP` for K3 is normal | stop |
| `python compare.py lumerical_R` | a row whose column `python_rcwa_epslin_vs_zemax_rcwa_rms` is `2.95e-05` | stop; reference tables not intact |
| `python zemax_kogelnik_nsc.py lumerical_R` (~5 min) then `python compare.py lumerical_R` | column `zemax_native_vs_my_kogelnik_max` ≤ `1e-06` | ZOS-API or the bench is not working here; report |

## Step 1 — native Kogelnik object, TM (25 minutes; any edition)

```
python zemax_kogelnik_nsc.py lumerical_R --pol TM
python compare.py --pol TM lumerical_R
```

The first writes `results\zemax_lumerical_R_TM.csv` and `zemax\kogelnik_native_lumerical_R_TM.zmx`.
Read `zemax_native_vs_my_kogelnik_max` in `results\summary_TM.csv`. Two possible outcomes, both are
findings, neither is a failure (gate **N1**):

- ≤ 10⁻⁶: OpticStudio's native model applies Kogelnik's TM factor (κ cos 2θ_c).
- about 10⁻² or more: compare the new table with the TE one, `results\zemax_lumerical_R.csv`. If they
  are identical, the native model ignores polarisation. If neither, compute the TM/TE ratio at Bragg
  and at θ = 7.5° and compare with 0.9154 and 0.5363 (referee) and 0.9154 and 0.5863 (Kogelnik), and
  describe what you see.

Then run the same two commands for `zemax_kba_R`, `lumerical_T` and `unslanted_T`. The outcome must
be the same on all four; if it is not, say so.

## Step 2 — RCWA DLL probe in TM (20 minutes; Premium/Enterprise only)

Make sure `vhg_constant_hologram230313.dll` is in `<ZemaxDataDir>\DLL\Diffractive\` (the data folder
printed by the licence check, usually `Documents\Zemax`; copy it from `zemax\ansys_kba\dll\` if
present, else see `README_DLL_REMOVED.md` there). Then:

`python zemax_rcwa_nsc.py --pol TM --probe lumerical_R > ..\results\zemax_rcwa_probe_TM.txt`

Gates (read the printout):

- **D0, reproducibility**: at 10 layers per period the TM values at θ = 0°, −14°, 7.5° are
  0.7272546, 0.0245981, 0.0520480 to 10⁻⁶ (measured 2026-09-18 on the same DLL and bench).
  If not: check Jy = 1, `UsePolarization`, Split NSC Rays ON, StartOrder = StopOrder.
- **D1, convergence**: the layer ladder 10/20/40/80/160/320 converges as 1/N² (differences falling by
  about 4 per rung); Max Order 3/5/9/13 agree to 10⁻⁶; energy over orders −3…3 = 1.000 ± 0.001; the
  converged TM Bragg value is within 10⁻⁴ of **0.736918** (the ε-linear TM referee).
- **D2, the discriminating point**: the converged TM value at θ = −14° lands near **0.0274**
  (ε-linear), not 0.0239 (exact) and not 0.0140 (Kogelnik). If it lands on 0.0239, the DLL's
  permittivity expansion is polarisation-dependent; that is a new finding, report it with the numbers.

## Step 3 — RCWA DLL sweeps in TM (about an hour)

```
python zemax_rcwa_nsc.py --pol TM lumerical_R
python zemax_rcwa_nsc.py --pol TM zemax_kba_R
python zemax_rcwa_nsc.py --pol TM lumerical_T
python zemax_rcwa_nsc.py --pol TM unslanted_T_rot5 --layers 320
```

Each writes `results\zemax_rcwa_<case>_TM.csv` and `zemax\rcwa_dll_<case>_TM.zmx`. **Do not run
`unslanted_T` on the DLL.** For `lumerical_T` the driver traces both integer orders and applies the
K·k labelling rule; keep its printout. A failed run writes `*.FAILED.csv`; report it, do not retry blindly.

## Step 4 — score (5 minutes)

```
python compare.py --pol TM
python summary_chart.py --pol TM
```

Circles are the native Kogelnik, squares the DLL; the lower panels show each solver's deviation from
the exact TM referee (dotted) and from the ε-linear TM referee (dashed). Look at every figure.

## The numbers that decide whether it worked

Converged Python referee, per 1 W incident. Full table: `evidence\tm_reference_values.md`.

| grating | θ (°) | λ (nm) | TE referee | **TM referee, exact** | **TM referee, ε-linear** (the DLL's form) | Kogelnik TM |
|---|---|---|---|---|---|---|
| `lumerical_R` | 0 and −28 (Bragg) | 550 | 0.804947 | **0.736870** | **0.736918** | 0.737264 |
| `lumerical_R` | −14 | 550 | 0.023944 | **0.023919** | **0.027389** | 0.014014 |
| `lumerical_R` | 7.5 | 550 | 0.100148 | **0.053714** | **0.053529** | 0.049672 |
| `lumerical_T` | 0 (Bragg) | 550 | 0.978518 | **0.916206** | **0.916025** | 0.922215 |
| `lumerical_T` | 5 | 550 | 0.013852 | **0.021129** | **0.020901** | 0.029352 |
| `zemax_kba_R` | −45 and 0 (Bragg) | 550 | 0.873784 | **0.694665** | **0.694597** | 0.695385 |
| `zemax_kba_R` | −22.5 | 550 | 0.012827 | **0.012825** | **0.011817** | 0.042365 |
| `unslanted_T_rot5` | 38.8627 (Bragg) | 500 | 0.573615 | **0.579853** | **0.579934** | 0.579477 |
| `unslanted_T_rot5` | 41 | 500 | 0.243315 | **0.018743** | **0.018821** | 0.014794 |

Gate **D3** on `results\summary_TM.csv`: `python_rcwa_epslin_vs_zemax_rcwa_rms` ≤ 10⁻⁴ on every sweep
(in TE it was 1–6 × 10⁻⁵, excluding the one point within 0.1° of `zemax_kba_R`'s first-order cut-off
at 17.03°), while `python_rcwa_vs_zemax_rcwa_rms` is 10⁻³ to 10⁻² (the n₁² terms the DLL drops).
Report both, and whether the gap between the two forms is larger in TM than in TE (the referee
predicts the same 3.5 × 10⁻³ at −14°).

If a gate fails: report the measured value and your diagnosis, mark the table `UNTESTED` or
`FAILED`, and do not loosen the gate.

## Step 5 — write the verdict and return

Write `results\opticstudio_tm_verdict.md`: the verdict first, in bold; the N1 finding with its
numbers; a table case × sweep with DLL-vs-exact-TM rms and max, DLL-vs-ε-linear rms and max, and
Kogelnik-TM-vs-DLL rms; the TM convergence ladder; the DLL's behaviour near `zemax_kba_R`'s cut-off
(θ = 16.8–17.0°) and at the 3.5° Rayleigh anomaly of `lumerical_R`; OpticStudio version and licence
edition; what remains UNTESTED.

Then zip the whole `remote_pack` folder and hand it back. It must contain: `results\zemax_<case>_TM.csv`
(four), `results\zemax_rcwa_<case>_TM.csv` (four), `results\zemax_rcwa_probe_TM.txt`, the `.zmx`
benches in `zemax\`, `results\summary_TM.csv`, the regenerated figures,
`results\opticstudio_tm_verdict.md`, and the final `code\zemax_rcwa_nsc.py` and
`code\zemax_kogelnik_nsc.py`. Do not rename files or change the CSV columns.

Finish with a short report in the chat: verdict; the N1 finding; the D0–D3 numbers; what you changed
in the drivers and why; what is still untested.

## Pitfalls already paid for (so you do not pay again)

- Jx = 1 is TE and Jy = 1 is TM on this y–z bench; `UsePolarization` is on; `RandomPolarization` off.
- DLL settings the shipped example gets wrong, already applied by the driver: `Only these orders` = 0
  (16 is an order filter), `Layer per period` = 160 (10 is 8.5 × 10⁻³ low), `Interpolation` = 0
  (16001 terminates OpticStudio at wavelength changes). Do not change them.
- The DLL implements ε = n₀² + 2n₀n₁cos(K·r), dropping the n₁² terms; that is why two referee forms
  are scored.
- K_z = 0 terminates the server; slabs thinner than one z-period return wrong values silently.
- Near the first-order cut-off of `zemax_kba_R` (θ = 16.8–17.0°) the DLL departed from both referee
  forms in TE; watch the same points in TM and report them separately.
- Native `Hologram Thickness` is in lens units (mm); the DLL's `Holo Thic (um)` is micrometres; the
  drivers handle both.
- The NSC minimum relative ray intensity must be 10⁻¹² (the bench sets it) or sidelobes below 10⁻³ read zero.
- Each DLL evaluation takes about 1.5 s at 160 layers per period.
- Do not call `DiffractionData.GetAvailableDLLs()`; it hung a headless session once.
