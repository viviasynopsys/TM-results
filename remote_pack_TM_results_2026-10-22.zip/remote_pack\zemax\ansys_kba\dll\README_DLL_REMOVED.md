# The RCWA hologram DLL is not in this copy of the pack

Gmail refuses archives that contain a `.dll`, so `vhg_constant_hologram230313.dll` (705,536 bytes)
was left out of the e-mailed variant of this pack (2026-10-16). The OpticStudio brief needs it in
`<ZemaxDataDir>\DLL\Diffractive\`. Get it from either source:

1. Ansys knowledge-base article 42661816933139, "Simulation of volume holographic grating using
   rigorous coupled-wave analysis method" (the article's downloadable example zip holds the DLL and
   `test_example1`); or
2. the September pack already on the OpticStudio PC (`17-09 ...\zemax\ansys_kba\dll\`), or the
   `test_example1.zar` in this pack, whose restore through the ZOS-API drops the DLL into
   `Documents\Zemax\DLL\Diffractive` (VERIFIED 2026-09-17).

Check before use: 705,536 bytes; the DLL log file it writes beside itself is `vhg_constant_hologram.txt`.
The Lumerical brief does not need the DLL at all.
