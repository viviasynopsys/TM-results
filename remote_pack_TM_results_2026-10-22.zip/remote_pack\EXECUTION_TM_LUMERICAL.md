# EXECUTION_TM_LUMERICAL.md — the Lumerical TM (p-polarisation) leg of the F-PSM benchmark

*Written 2026-10-16 for Claude Sonnet 5.5 (Claude Code) on a PC with **Ansys Lumerical
(Enterprise)** installed. You have no other context; everything you need is in this folder or in
this file. Read the whole file before running anything. British English throughout. This pack is a
slice of a larger project; you bring results back (`RETURN.md`), you do not rewrite the project.*

## 0. Your job in one paragraph

In September 2026 this driver (`code/lumerical_rcwa.py`) ran Lumerical's RCWA solver on five
volume gratings and reproduced an independent Python referee to between 10⁻¹² and 4×10⁻⁵ rms, for
**TE (s) polarisation** (`reference/lumerical_verdict.md`). Lumerical's RCWA object solves s and p
together and reports them as separate result attributes; the September run read only the s
attributes (`Rs_power`, `Ts_power`). **Your job is to re-run the five cases with the extended
driver, which now also reads the p attributes (`Rp_power`, `Tp_power`) and writes a TM table
beside the TE one from the same solve, then score the TM tables against the TM referee and write
a short verdict.** Along the way you re-dump the solver's property and result lists in full (the
September dump was truncated by numpy's print threshold), record a TM convergence ladder on G1,
and, optionally, try one absorbing grating. The TE tables you produce are compared with the
September ones as a reproducibility check.

**Rules of engagement.** (1) Every claim you write carries a status and a date: `VERIFIED <date>`,
`ASSUMED`, `UNTESTED`. (2) Never fabricate or tune a number to make curves agree; if Lumerical
disagrees with the referee, that *is* the result: find out why and report it. (3) Fail loudly: no
silent zero, no plausible default; a failed run must not overwrite a good table (the driver writes
`*.FAILED.csv` instead). (4) Never hand-edit `.fsp`, `.zar`, `.zmx` or any binary; change models
only through `lumapi`. (5) Verdict first, evidence after. (6) Do not modify anything in
`lumerical/ansys_example/`, `reference/`, or the existing columns of `results/summary.csv`.
(7) You do not need OpticStudio for anything here; if it is installed, leave it alone.

## 1. Background — the physics (short; the long form is `reference/execution_original.md` §1)

A volume holographic grating: a slab of thickness *d* with index n(**r**) = n₀ + n₁ cos(**K**·**r**),
recorded by two collimated beams **k₁**, **k₂** inside the medium at wavelength λ_r, so
**K** = (2πn₀/λ_r)(**k₁** − **k₂**). Replayed near **k₁** it diffracts into **k₂** (the first order).
The quantity compared is the first-order diffraction efficiency η (fraction of incident power)
versus replay angle θ in the medium at fixed λ, and versus λ at the Bragg angle. Lossless,
index-matched exterior (background index n₀, no Fresnel faces), angles inside the medium.

**TE and TM.** TE (s): electric field perpendicular to the plane of incidence (Lumerical's `Rs_`,
`Ts_`). TM (p): electric field in the plane of incidence (`Rp_`, `Tp_`). In TM the coupling
between the two principal waves carries the cosine of the angle between them, so TM efficiencies
are lower at Bragg (G1: 0.805 → 0.737) and can be very different in the sidelobes (G1 at 7.5°:
0.100 → 0.054). The TM referee is a Maxwell-exact vector RCWA; `evidence/tm_reference_values.md`
holds its values at every gate point, TE beside TM.

The five gratings (all n₀ = 1.5; `code/cases.py` is the single definition, every engine reads it):

| case | n₁ | d | λ_r = λ | recording beams | type | slant Ψ | article-model inputs (angle 1, angle 2, holo type) |
|---|---|---|---|---|---|---|---|
| `lumerical_R` | 0.04 | 6 µm | 550 nm | 0°, 28° opposite sides | reflection | 14° | 0, 28, R |
| `lumerical_T` | 0.04 | 6 µm | 550 nm | 0°, 28° same side | transmission | 76° | 0, 28, T |
| `zemax_kba_R` | 0.05 | 5 µm | 550 nm | −45°, 0° opposite sides | reflection | 22.5° | −45, 0, R |
| `unslanted_T` | 0.03 | 10 µm | 500 nm | ±33.8627° | transmission | −90° | bypass (K_z = 0), see §5 step 4 |
| `unslanted_T_rot5` | 0.03 | 10 µm | 500 nm | G4 turned 5° | transmission | −95° | 38.8627, −28.8627, T |

## 2. What is in the pack (the parts this brief uses)

```
code/cases.py                   THE grating definitions
code/rcwa.py                    the referee, TE + TM, exact / eps-linear permittivity   (gated 2026-10-16)
code/kogelnik.py                Kogelnik TE + TM
code/fpsm.py                    F-PSM, TE only (raises for TM -- by design; nothing to do with it here)
code/test_*.py                  the gates (step 0)
code/check_env.py               step 0
code/lumerical_rcwa.py          THE DRIVER.  TE path VERIFIED 2026-09-18 on Lumerical v261 (engine 8.35.4522);
                                TM additions UNTESTED at the solver (they read attributes whose NAMES are in the
                                September dump but whose VALUES were never read)
code/compare.py                 figures + scores; --pol TM
code/summary_chart.py           the summary picture; --pol TM
results/lumerical_rcwa_<case>.csv      the September TE tables (reproducibility reference)
results/compare_<case>_TM_*.csv        the TM referee and Kogelnik at every sweep point (your curve goes beside them)
results/summary_TM.csv                 the TM scores so far (Python legs only)
evidence/tm_reference_values.md        THE NUMBERS TO HIT
reference/lumerical_verdict.md         the September Lumerical verdict: every property name settled, every pitfall
reference/lumerical_probe_2026-09-18.txt   the September (truncated) dump, for comparison
reference/EXECUTION_LUMERICAL_original.md  the September brief (long form of everything here)
lumerical/ansys_example/vhg_R_6um_model.fsp  the article's model -- do not modify
```

## 3. What is missing

`results/lumerical_rcwa_<case>_TM.csv` (five), the re-run `results/lumerical_rcwa_<case>.csv`
(five), a complete `results/lumerical_probe.txt`, `results/lumerical_converge_lumerical_R.txt` with
TM columns, `lumerical/rcwa_<case>.fsp`, the regenerated TM figures and `summary_TM.csv`, and
`results/lumerical_tm_verdict.md`.

Table schema (one schema for every Ansys table; `compare.py` depends on the first five columns):
`sweep` (`angle`|`wavelength`), `source_tilt_x_deg` (**= −θ**, degrees), `lambda_um`,
`P_entry_side_W` (reflected first order, per 1 W incident), `P_far_side_W` (transmitted first
order); then `order`, `harmonics`, `layers_per_period`, and the raw values of both integer orders.
The TM table has exactly the same columns, filled from the p attributes.

## 4. Environment

Windows. Python ≥ 3.10 with `numpy`, `matplotlib`. **Use a Windows Python, not WSL**: `lumapi`
loads Lumerical's own DLLs. `lumapi.py` ships with Lumerical under `<install>\api\python\`; the
driver finds it by scanning the usual install roots, else set `LUMAPI_PATH` to its full path.
Never hard-code an install path. Run every script from inside `code/`. Lumerical must be
≥ 2025 R1 for layer repetition (the September run used 2026 R1, v261). The session is headless
(`lumapi.FDTD(filename=..., hide=True)`). If a licence dialog or an RCWA-licence error appears,
stop and report it.

## 5. Procedure

**Step 0 — prove the pack on this machine (10 min).**
`python check_env.py lumerical` → `READY`.
`python test_fpsm_vectors.py` → `0 failure(s)` (81 checks).
`python test_engines.py` → `0 failure(s)` (a `SKIP … PSMGRATING_PATH` line is expected).
`python test_tm_referee.py` → `0 failure(s)`; gates G3 and G4 report **SKIP** here (their oracles
live on the benchmark PC) — that is expected; G1, G2, G5, G6, G7 must pass.
`python test_kogelnik_pol.py` → `0 failure(s)`, K3 SKIP expected.
`python compare.py lumerical_R` → the printed row's column `python_rcwa_epslin_vs_zemax_rcwa_rms`
is 2.95×10⁻⁵ (to 3 s.f.) — the TE referee, scoring and reference tables are intact here.
`python compare.py --pol TM lumerical_R` → runs, prints two `no …_TM.csv` notices (your tables do
not exist yet), and rewrites `results/compare_lumerical_R_TM_angle.csv` identically to the one
shipped (diff it: numbers equal to ≤ 10⁻¹²; a library difference at that level is fine).

**Step 1 — probe (5 min).** `python lumerical_rcwa.py --probe lumerical_R` → a complete
`results/lumerical_probe.txt`. Confirm, in the `grating_power` and `total_energy` datasets, that
the attributes `Rp_power`, `Tp_power` and `Rp`, `Tp` exist with the same shapes as the s ones
(`(1, N_theta, N_order, 1, 2)` and `(1, N_theta, 2)`). If the names differ on this build, correct
the four `res_*p` entries of the NAME MAP `P` in the driver and say so (VERIFIED-by-probe).

**Step 2 — one solve at Bragg (5 min).** `python lumerical_rcwa.py --bragg lumerical_R` (shipped
settings: 10 layers per period). It prints the TE order table (as in September) and now the TM
one, the energy sums for both, and the referee values. Gates L0 and **T0** (§6).

**Step 3 — converge (20 min).** `python lumerical_rcwa.py --converge lumerical_R` →
`results/lumerical_converge_lumerical_R.txt`, each rung with the TE values and, after `TM:`, the TM
values at θ = 0°, −14°, 7.5°. Gate **T2**: the TM ladder converges like the TE one (from below,
roughly as 1/N² in layers; harmonics 3 = 5 = 9 = 13). The September converged settings were
3 harmonics and 160 layers per period; keep them unless the TM ladder says otherwise.

**Step 4 — the five sweeps (about 1 h).** `python lumerical_rcwa.py <case> --harmonics 3
--layers 160` for `lumerical_R`, `zemax_kba_R`, `lumerical_T`, `unslanted_T`, `unslanted_T_rot5`
→ `results/lumerical_rcwa_<case>.csv` **and** `results/lumerical_rcwa_<case>_TM.csv`,
`lumerical/rcwa_<case>.fsp`. Per case:
- `lumerical_R` first; the TE preview line must show `exact rms ≈ 3×10⁻⁵`, the TM preview line is
  the new number — expect the same order of magnitude (gate T1 is decided by `compare.py`).
- `lumerical_T`: past θ = 14° the "first order" label swaps to the conjugate integer order (the
  convention of `compare.py` and OpticStudio). The driver fits the sign and picks the order on the
  TE curve, where the referee is confirmed, and applies the same choice to TM — report that it did.
- `unslanted_T`: K_z = 0; the driver's `configure_unslanted` bypass blanks the setup script and
  writes the index equation itself (VERIFIED 2026-09-18 to be accepted by `lumapi`). Do not
  rotate the grating instead.
- `unslanted_T_rot5` last; it lets the two Ansys solvers meet on one grating.

**Step 5 — overlay and score (5 min).** `python compare.py --pol TM` (all cases), then
`python summary_chart.py --pol TM`. The TM tables are picked up automatically, drawn as triangles
on `figures/compare_<case>_TM.png` with their deviation from the TM referee in the lower panels,
and scored in `results/summary_TM.csv` (`python_rcwa_vs_lumerical_rcwa_rms/_max`,
`kogelnik_vs_lumerical_rcwa_rms`, `python_rcwa_epslin_vs_lumerical_rcwa_rms/_max`). Also run
`python compare.py` (TE) so the re-run TE tables are rescored; compare its `summary.csv` Lumerical
columns with `reference/summary_2026-09-30.csv` (gate **R0**). **Look at every figure.**

**Step 6 — optional absorption probe (10 min; only after 1–5 pass).**
`python lumerical_rcwa.py --bragg lumerical_R --chi0 1e-3 --harmonics 3 --layers 160`. The driver
appends `-0.001i` to the rectangle's spatial index equation after the setup script has built it,
so n = (1.5 − 0.001 i) + 0.04 cos(**K**·**r**). Whether the index equation accepts a complex value
is **UNTESTED**. Gate **A0**: the printed energy sums fall to ≈ 0.9156 (TE) and ≈ 0.9094 (TM) and
the first order to ≈ 0.7360 (TE) / 0.6688 (TM) (`evidence/tm_reference_values.md`, last table;
tolerance 2×10⁻³ at 160 layers). If the driver raises "imaginary index was ignored", record that
the index equation is real-only on this build, note what the Lumerical material dialog offers
instead (an (n,k) material with a spatially varying imaginary part, if any — read, do not build),
and stop; do not spend more than ten minutes on this step.

**Step 7 — write up.** `results/lumerical_tm_verdict.md`: verdict first, in bold; a table case ×
sweep with TM referee-vs-Lumerical rms and max, Kogelnik-TM-vs-Lumerical rms, and the ε-linear
column; whether TM sits on the exact referee as TE did; the R0 reproducibility numbers; every
`ASSUMED`/`UNTESTED` label you settled and how (quote the probe); converged settings; Lumerical's
version and licence edition; what remains UNTESTED. Then follow `RETURN.md`.

## 6. Acceptance gates — how you know it is right

Reference values from the converged Python referee (L = 14), per 1 W incident, first order on the
entry face (R+1, reflection cases) or far face (T+1, transmission cases); T0 the undiffracted beam.
Full table with every column: `evidence/tm_reference_values.md`.

| case | θ (°) | λ (nm) | TE referee | **TM referee** | TM, ε-linear | TM T0 | Kogelnik TM |
|---|---|---|---|---|---|---|---|
| `lumerical_R` | 0 and −28 (Bragg) | 550 | 0.804947 | **0.736870** | 0.736918 | 0.2629 | 0.737264 |
| `lumerical_R` | −14 | 550 | 0.023944 | **0.023919** | 0.027389 | 0.9760 | 0.014014 |
| `lumerical_R` | 7.5 | 550 | 0.100148 | **0.053714** | 0.053529 | 0.9460 | 0.049672 |
| `lumerical_T` | 0 (Bragg) | 550 | 0.978518 | **0.916206** | 0.916025 | 0.0796 | 0.922215 |
| `lumerical_T` | 5 | 550 | 0.013852 | **0.021129** | 0.020901 | 0.9741 | 0.029352 |
| `zemax_kba_R` | −45 and 0 (Bragg) | 550 | 0.873784 | **0.694665** | 0.694597 | 0.3051 | 0.695385 |
| `zemax_kba_R` | −22.5 | 550 | 0.012827 | **0.012825** | 0.011817 | 0.9870 | 0.042365 |
| `unslanted_T` | 33.8627 (Bragg) | 500 | 0.586035 | see reference file | | | |
| `unslanted_T` | 36 | 500 | 0.243709 | see reference file | | | |

The off-Bragg rows discriminate: at −14° on G1 the exact TM referee gives 0.0239, the ε-linear
form 0.0274 and Kogelnik TM 0.0140. A genuine TM RCWA lands on one of the two referee columns.
At 7.5° TE and TM differ by a factor of two — a p-attribute that reproduces the **TE** column
there is the s attribute under another name.

- **L0** (step 2, TE as in September): one order carries R ≈ 0.80 at Bragg; Σ over all orders of
  (R + T) = 1.000 ± 10⁻³; the simulated thickness reads back as 6.000 µm.
- **T0** (step 2, TM): the TM Bragg peak sits in the **same order index** as the TE peak; TM energy
  Σ = 1.000 ± 10⁻³; the ratio TM/TE at Bragg is 0.915 ± 0.005 whatever the layer count (the
  discretisation error largely cancels in the ratio; the referee ratio is 0.9154).
- **T2** (step 3): TM converged in harmonics and layers to < 10⁻⁴ at Bragg and off-Bragg; at 160
  layers expect TM ≈ 0.73684 ± 5×10⁻⁵ at Bragg (TE was 0.804914 against 0.804947).
- **T1** (step 5): `python_rcwa_vs_lumerical_rcwa_rms` ≤ 10⁻³ in `summary_TM.csv` on every case,
  expected 10⁻⁵ to 4×10⁻⁵ on the slanted gratings and ≈ 10⁻¹² on `unslanted_T`, **and** nearer the
  exact form than the ε-linear one (TE was 30–100× nearer). Report which.
- **R0** (step 5): the re-run TE tables agree with the September ones to rms ≤ 10⁻⁶ per sweep
  (same build, same settings → same numbers; a larger difference means a setting changed).
- **A0** (step 6, optional): as stated there.
- **If a gate cannot be met,** do not loosen it silently: report the measured value, your
  diagnosis, and mark the affected table `UNTESTED` or `FAILED`.

## 7. Pitfalls already paid for (VERIFIED 2026-09-18 unless marked)

- **There is no polarisation property.** s and p are solved together; TE is `Rs_power`/`Ts_power`,
  TM is `Rp_power`/`Tp_power` (names in the probe dump; values UNTESTED until you read them).
- **Thickness is the RCWA object's layer repetition**, not a model property; `simulation z span`
  includes the background padding; the driver reads the true thickness back and refuses on a
  mismatch. The setup script re-runs at every solve and silently restores geometry it owns.
- **Layers per period** are the `interface reference positions` count (shipped 10). 160 was the
  converged value in TE; TM may need its own check (gate T2).
- **Dn is the cosine amplitude** (0.04), not peak-to-peak.
- **Order labelling** on `lumerical_T` (θ > 14°): conjugate order; the driver and `compare.py`
  share the rule. **Cut-off** on `zemax_kba_R` near θ = 17°: Lumerical behaved; watch the same
  points in TM and report them separately if not.
- **Angle sign** is fitted, never assumed (it was +1 on all four cases in September).
- **The ε-form.** The OpticStudio DLL drops the n₁² terms of ε = n²; Lumerical keeps them (TE,
  September). `compare.py` scores your TM tables against both forms; which one TM follows is a
  result, not an assumption.
- **numpy print threshold**: the September probe dump elided the large arrays; the driver now sets
  the threshold to unlimited before dumping.
- **Long solves**: angle sweeps are 141–201 points, wavelength sweeps 101; run long ones in the
  background and watch their log.
- Ansys knowledge-base pages return HTTP 403 to plain fetches; the three relevant articles are in
  `reference/` as text.

## 8. Deliverables checklist

- [ ] step 0 outputs: `READY`; `0 failure(s)` ×4 (with the expected SKIPs); `compare.py lumerical_R` reproduces 2.95×10⁻⁵
- [ ] `results/lumerical_probe.txt`, complete, with the four p attributes confirmed
- [ ] `results/lumerical_converge_lumerical_R.txt` with TM columns; converged settings stated
- [ ] `results/lumerical_rcwa_<case>.csv` and `results/lumerical_rcwa_<case>_TM.csv`, five each; `lumerical/rcwa_*.fsp`
- [ ] regenerated `figures/compare_<case>_TM.png` ×5 and `figures/summary_rms_TM.png`; `results/summary_TM.csv` with the Lumerical columns filled; `results/summary.csv` re-scored (gate R0)
- [ ] `results/lumerical_tm_verdict.md`
- [ ] the final `code/lumerical_rcwa.py`
- [ ] (optional) the absorption probe printout

Finish with a short report: verdict; the TM agreement numbers; which ε form TM follows; the R0
numbers; what you changed in the driver and why; what is still untested. If something is blocked
by a licence, an access control or a missing product, say exactly what and stop there.
