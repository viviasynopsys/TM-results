# RETURN.md — what to bring back, and how it is merged

*2026-10-16. The pack is a slice of `C:\Users\vivia\Code2\1_Optics\Research\2026-10-16\` on the
benchmark PC. Everything you produce is merged there; nothing here is rewritten by hand.*

## Bring back (zip the whole pack folder, or at least these)

**From the Lumerical brief**
- `results/lumerical_rcwa_<case>_TM.csv` for the five cases, and the re-run TE tables
  `results/lumerical_rcwa_<case>.csv` (five; they are compared with the September tables as a
  reproducibility check)
- `results/lumerical_probe.txt` (the complete, un-elided dump) and
  `results/lumerical_converge_lumerical_R.txt` (now with TM columns)
- `lumerical/rcwa_<case>.fsp` as saved by Lumerical
- `results/lumerical_tm_verdict.md`
- the final `code/lumerical_rcwa.py` (every `ASSUMED`/`UNTESTED` label either confirmed, with the
  evidence noted, or still standing and explained)
- if the optional absorption probe was run: its printout saved as `results/lumerical_absorption_probe.txt`

**From the OpticStudio brief**
- `results/zemax_<case>_TM.csv` for `lumerical_R`, `zemax_kba_R`, `lumerical_T`, `unslanted_T`
  (native Kogelnik, Jy = 1) and `zemax/kogelnik_native_<case>_TM.zmx`
- `results/zemax_rcwa_<case>_TM.csv` for `lumerical_R`, `zemax_kba_R`, `lumerical_T`,
  `unslanted_T_rot5` (RCWA DLL) and `zemax/rcwa_dll_<case>_TM.zmx`
- the probe printouts saved as `results/zemax_rcwa_probe_TM.txt` (and `results/zemax_rcwa_probe_TE.txt`
  if a TE probe was repeated), plus the DLL log tail they print
- `results/opticstudio_tm_verdict.md`
- the final `code/zemax_rcwa_nsc.py` and `code/zemax_kogelnik_nsc.py`

**From both**
- the regenerated `figures/compare_<case>_TM.png`, `figures/summary_rms_TM.png` and
  `results/summary_TM.csv` (compare.py / summary_chart.py write them; they are checked, not kept,
  on the benchmark PC, which regenerates them from your tables)
- a short final report in the chat: verdict; the agreement numbers; what you changed in the
  drivers and why; what is still untested; versions and licence editions used.

## How it is merged on the benchmark PC

1. Your `results/*_TM.csv`, `results/lumerical_rcwa_*.csv`, probe and convergence printouts and
   verdicts are copied into `2026-10-16/results/` (Ansys tables are never edited; a table that
   fails its gate stays as `*.FAILED.csv` beside the verdict that explains it).
2. `python compare.py --pol TM` and `python summary_chart.py --pol TM` are run there; the TM
   scores land in `results/summary_TM.csv` and the figures are regenerated.
3. Your driver versions are diffed against the pack's; every confirmed `ASSUMED`/`UNTESTED` label
   is carried over with your date.
4. The TM report (`REPORT_TM.md`) is extended with the Ansys legs, and the technical report's
   second edition is written from it.

Do not rename files, do not change the CSV schema (`sweep, source_tilt_x_deg, lambda_um,
P_entry_side_W, P_far_side_W, ...`), do not reorder the five cases.
