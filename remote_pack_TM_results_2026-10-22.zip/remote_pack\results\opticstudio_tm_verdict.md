# OpticStudio TM leg — verdict (2026-10-22)

**Verdict: PASS with one flagged exception. The OpticStudio RCWA DLL, run with a TM source (Jy = 1), reproduces the ε-linear TM referee (the DLL's own permittivity form) to 4 × 10⁻⁶ – 6 × 10⁻⁵ rms on seven of the eight sweeps; the eighth, `zemax_kba_R` angle, is 1.9 × 10⁻⁴ rms because of one point (θ = 17.0°, 0.03° below the first-order cut-off) and is 1.9 × 10⁻⁵ without it (gate D3 as written, ≤ 10⁻⁴, therefore FAILS on that sweep as scored, and passes once the documented cut-off point is excluded). D0, D1 and D2 pass. The DLL follows the ε-linear form in TM exactly as in TE, and the gap between the two forms is the same in TM and TE. The native Kogelnik object (N1) is polarisation-aware but is *not* the κ·cos 2θ_c model: it equals Kogelnik-TM at Bragg and departs from it by 5 × 10⁻³ – 4 × 10⁻² elsewhere.** VERIFIED 2026-10-22.

Machine: OpticStudio 26.1.4 (ZOS-API 26.1), licence `EnterpriseEdition`, ZemaxDataDir `C:\Users\vivia\OneDrive - Synopsys, Inc\Documents\Zemax`; Python 3.13.14, pythonnet (installed this session), `ZEMAX_ROOT` = `C:\Program Files\Ansys Inc\v261\Zemax OpticStudio`. The harmless messages `Missing cluster url!`, `Invalid job setup file!` and `FRU__delta_init(): Attempt to start when running!` appeared on every run.

## Getting the DLL (not in the e-mailed pack)
`vhg_constant_hologram230313.dll` was absent from `<ZemaxDataDir>\DLL\Diffractive`, from the pack folder and from the September pack. As `README_DLL_REMOVED.md` describes, I restored `zemax\ansys_kba\test_example1.zar` through the ZOS-API (`PrimarySystem.Tools.OpenRestoreZAR()`, output to a scratch folder in the session area, not the pack). The DLL then appeared in `Diffractive\` at **705,536 bytes**, the size the README gives. Nothing under `zemax\ansys_kba\` was modified. VERIFIED 2026-10-22.

## Step 0 – pack proof
`check_env.py opticstudio` READY; the four `test_*.py` scripts as in the Lumerical verdict (0 failures; G3, G4, K3 and the explorer check skipped for want of an oracle). Native Kogelnik TE `lumerical_R` re-run (5 min): `zemax_native_vs_my_kogelnik_max` = 3.908e-08 (angle) and 5.9e-13 (wavelength), both ≤ 10⁻⁶. VERIFIED 2026-10-22. (`results\zemax_lumerical_R.csv` was rewritten by this run.)

## Step 1 – native Kogelnik object in TM; finding N1
Run on all four cases (`lumerical_R`, `zemax_kba_R`, `lumerical_T`, `unslanted_T`). `zemax_native_vs_my_kogelnik_max` against Kogelnik-TM (κ cos 2θ_c):

| case | angle | wavelength |
|---|---|---|
| `lumerical_R` | 5.35e-03 | 4.27e-03 |
| `zemax_kba_R` | 1.53e-02 | 1.50e-02 |
| `lumerical_T` | 3.62e-02 | 2.70e-02 |
| `unslanted_T` | 2.70e-02 | 2.71e-02 |

None is ≤ 10⁻⁶, so the native model does **not** apply the κ cos 2θ_c factor. Nor does it ignore polarisation: the TM tables differ from the TE tables (max |TM − TE| on the power columns: 0.176, 0.391, 0.092, 0.237 W for the four cases). Detailed comparison on `lumerical_R` (angle sweep, entry-side power):

| θ | native TE | native TM | native TM/TE | referee TM/TE | Kogelnik TM/TE |
|---|---|---|---|---|---|
| 0° (Bragg) | 0.805403 | 0.737264 | 0.9154 | 0.9154 | 0.9154 |
| −14° | 0.014014 | 0.014001 | 0.9991 | | |
| 7.5° | 0.084730 | 0.047647 | **0.5623** | 0.5363 | 0.5863 |

So the native model is polarisation-dependent, equals Kogelnik-TM at Bragg (0.737264 to six figures), and off Bragg lies between the rigorous TM result and Kogelnik-TM (ratio 0.5623 against 0.5363 and 0.5863). Its closed form is therefore not identified; I have not tried to fit one. The outcome is the same in kind on all four cases (none ≤ 10⁻⁶, none identical to TE). Gate N1 is a finding, not a failure. VERIFIED 2026-10-22.

## Step 2 – DLL TM probe (`results\zemax_rcwa_probe_TM.txt`, converted from PowerShell's UTF-16 to UTF-8; content unchanged)
- **D0 reproducibility: PASS.** At 10 layers the TM values at θ = 0°, −14°, 7.5° are 0.7272546, 0.0245981, 0.0520480 (full: 0.72725458, 0.02459811, 0.05204801), identical to the 2026-09-18 values to 10⁻⁶.
- **D1 convergence: PASS.** Layer ladder at Bragg (10/20/40/80/160/320): 0.727255, 0.734521, 0.736320, 0.736769, 0.736881, 0.736909; successive differences 7.27e-3, 1.80e-3, 4.49e-4, 1.12e-4, 2.8e-5 (ratio 4.04, 4.01, 4.01, 3.99, i.e. 1/N²). Max Order 3/5/9/13 agree to ≈ 10⁻¹¹. Energy over orders −3…3 = 1.000000. Converged TM Bragg 0.736881 at 160 layers (3.7 × 10⁻⁵ from 0.736918, within the 10⁻⁴ gate) and 0.736909 at 320.
- **D2 discriminating point: PASS, ε-linear.** TM at θ = −14°: 0.027377 (160 layers), 0.027386 (320). Referee ε-linear 0.027389, exact 0.023919, Kogelnik 0.014014. The DLL's permittivity expansion is *not* polarisation-dependent. At 7.5°: 0.053523 / 0.053527 against ε-linear 0.053529 and exact 0.053714.
- Interpolation ladder (extra): 0 and 4001 agree to 4e-6, 1001 differs by 1.6e-3 at θ = −14°, as the pack warned; the driver keeps Interpolation = 0.

## Step 3 – DLL sweeps (settings: Max Order 5, 160 layers per period, 320 for `unslanted_T_rot5`, Interpolation 0, Only these orders 0)
All four ran to completion, no `*.FAILED.csv`. `unslanted_T` was not run on the DLL (K_z = 0). `lumerical_T`: 72 of 141 angle points use the conjugate order −1, both orders traced, K·k labelling applied by the driver. `unslanted_T_rot5` uses order −1 throughout (Bragg: 0.579920 against ε-linear 0.579934). DLL TM/TE ratios on `lumerical_R`: 0.9154 at 0°, 0.9990 at −14°, 0.5332 at 7.5° (ε-linear referee ratio 0.5332).

## Step 4 – gate D3 (`results\summary_TM.csv`)
| case | sweep | DLL vs exact TM: rms / max | DLL vs ε-linear TM: rms / max | Kogelnik-TM vs DLL rms |
|---|---|---|---|---|
| `lumerical_R` | angle | 3.92e-03 / 9.01e-03 | 2.82e-05 / 5.72e-05 | 8.85e-03 |
| `lumerical_R` | wavelength | 2.13e-03 / 8.84e-03 | 1.66e-05 / 5.48e-05 | 9.20e-03 |
| `zemax_kba_R` | angle | 3.58e-03 / 1.22e-02 | **1.86e-04** / 2.55e-03 (1.94e-05 without θ = 17.0°) | 1.66e-02 |
| `zemax_kba_R` | wavelength | 3.57e-03 / 1.17e-02 | 1.94e-05 / 5.10e-05 | 1.00e-02 |
| `lumerical_T` | angle | 4.44e-04 / 3.86e-03 | 2.58e-05 / 7.46e-05 | 1.57e-02 |
| `lumerical_T` | wavelength | 6.00e-04 / 8.79e-04 | 5.73e-05 / 8.14e-05 | 1.97e-02 |
| `unslanted_T_rot5` | angle | 1.26e-04 / 4.69e-04 | 3.60e-06 / 1.58e-05 | 8.53e-03 |
| `unslanted_T_rot5` | wavelength | 1.48e-04 / 5.12e-04 | 4.34e-06 / 1.61e-05 | 9.77e-03 |

- **D3 as written: 7 of 8 sweeps pass; `zemax_kba_R` angle fails (1.86e-4 > 10⁻⁴)** because of a single point. Without it the sweep is 1.94 × 10⁻⁵ (VERIFIED by recomputing from `zemax_rcwa_zemax_kba_R_TM.csv` and `compare_zemax_kba_R_TM_angle.csv`). The TE leg showed the same single-point departure (TE ε-linear rms 3.42e-3 on this sweep in `results\summary.csv`, identical to September), which the brief's gate wording already excludes. I have not loosened the gate; the failing number is recorded here.
- The exact-form rms is 10⁻³ – 10⁻² on the two reflection gratings, as expected from the n₁² terms the DLL drops. On `lumerical_T` and `unslanted_T_rot5` it is 10⁻⁴ – 10⁻³ (smaller n₁² effect); TE was 8 × 10⁻⁴ – 1.4 × 10⁻³ and 1.9 × 10⁻⁴ – 2.1 × 10⁻⁴ there, so TM is not worse.
- **Gap between the two referee forms:** at θ = −14° on `lumerical_R` it is 3.47 × 10⁻³ in TM (0.027389 − 0.023919) and 3.47 × 10⁻³ in TE (0.027415 − 0.023944): the same, as the referee predicts. The rms exact-form gap on `lumerical_R` angle is 3.9 × 10⁻³ (TM) against 4.2 × 10⁻³ (TE).
- **Cut-off of `zemax_kba_R` (θ = 16.8–17.0°):** TM DLL at 17.0° = 0.000106, against ε-linear 0.002657 and exact 0.001575 (deviation −2.55e-3, the largest in any sweep). The points at 16.8° and 16.9° are within 5.0 × 10⁻⁵ of ε-linear, so the departure is confined to the last point before the cut-off at 17.03°. TE shows the same behaviour.
- **Rayleigh anomaly of `lumerical_R` at θ = 3.5°:** DLL TM deviates from the ε-linear referee by 4.7 × 10⁻⁵ there, within the sweep's 5.7 × 10⁻⁵ maximum; nothing unusual. (VERIFIED 2026-10-22; the sweep step is 0.5°, so the anomaly is sampled at exactly 3.5° only.)

Figures: looked at `figures\compare_*_TM.png` (circles native, squares DLL, triangles Lumerical) and `figures\summary_rms_TM.png`. The DLL squares sit on the TM curves, Lumerical triangles are the closest to the exact referee, and the DLL's deviation from the ε-linear referee (open squares) is 10⁻⁵ – 10⁻⁴ everywhere except the one point above.

## Changes to the drivers
None. `code\zemax_rcwa_nsc.py` and `code\zemax_kogelnik_nsc.py` are as shipped. `zemax_rcwa_nsc.py` prints a harmless `SyntaxWarning: invalid escape sequence '\D'` from its docstring on Python 3.13; I left it. Environment changes only: `pythonnet` installed, `ZEMAX_ROOT` set, the DLL restored into `<ZemaxDataDir>\DLL\Diffractive`.

## UNTESTED
The functional form of OpticStudio's native TM factor (only measured, not identified); the sampling of the 3.5° Rayleigh anomaly finer than 0.5°; the DLL on `unslanted_T` (excluded because K_z = 0 terminates OpticStudio).
