# RESTORE_EXTENSIONS.md — read this first

*Pack: the TM leg of the F-PSM volume-grating benchmark, built 2026-10-16; this copy made 2026-10-22
for e-mail. British English.*

Every file in this pack except this one has been renamed so that its extension is `.txt`. **Nothing
inside any file was changed.** Before doing anything else, give every file its original name back,
using the table at the end. 92 files are listed; 83 were renamed and 9 were already `.txt` and kept their names.

Naming rule used: `name.ext` became `name.txt`. Where two files in one folder would have become the
same `name.txt`, both became `name_ext.txt` instead (one case: `test_example1.zmx` and
`test_example1.ZDA`). The table is the authority, not the rule.

The Ansys RCWA hologram DLL is **not** in this copy (Gmail refuses archives containing a `.dll`);
`zemax/ansys_kba/dll/README_DLL_REMOVED.md` (after restoring) says where to get it. The Lumerical
leg does not need it.

## What to do (for the agent on the work PC)

1. Extract the zip. This file sits in the `remote_pack` folder; work from there.
2. Save the Python block below as `restore_extensions.py` in that folder and run
   `python restore_extensions.py`. It checks the size and SHA-256 of **every** file against the
   table first and renames nothing unless all match; it is safe to run twice.
   No Python yet? Save the PowerShell block as `restore_extensions.ps1` and run
   `powershell -ExecutionPolicy Bypass -File restore_extensions.ps1` instead.
3. Pass: it prints `restored 83 files … 0 checksum mismatches`. Anything else: stop and
   report the printout; do not rename by hand around a checksum mismatch (the file was damaged in
   transit; ask for the zip again).
4. Check that `CLAUDE.md`, `INSTRUCTIONS_LUMERICAL_PC.md`, `INSTRUCTIONS_OPTICSTUDIO_PC.md` and
   `code/cases.py` now exist. Delete `restore_extensions.py` / `.ps1` (they are not part of the pack).
5. Then follow `INSTRUCTIONS_LUMERICAL_PC.md` (Lumerical machine) or `INSTRUCTIONS_OPTICSTUDIO_PC.md`
   (OpticStudio Premium/Enterprise machine) exactly, step by step.

## Restore script — Python

```python
"""restore_extensions.py -- give every file of this pack its original name back.
Reads RESTORE_EXTENSIONS.md (same folder), checks the SHA-256 of EVERY file first, renames only if
all match, and is safe to run twice.  Usage, from inside the remote_pack folder:
    python restore_extensions.py
"""
import hashlib, os, sys
here = os.path.dirname(os.path.abspath(__file__))
md = open(os.path.join(here, "RESTORE_EXTENSIONS.md"), encoding="utf-8").read()
# the table follows the LAST begin-marker (the marker text also appears inside this script's own listing)
block = md.rsplit("<!-- MANIFEST-BEGIN -->", 1)[1].split("<!-- MANIFEST-END -->")[0]
rows = []
for line in block.splitlines():
    c = [x.strip().strip("`") for x in line.split("|")]
    if len(c) > 6 and c[1].isdigit():
        rows.append((c[2], c[3], int(c[5]), c[6].lower()))
EXPECTED = 92
if len(rows) != EXPECTED:
    sys.exit(f"read {len(rows)} manifest rows, expected {EXPECTED} -- NOTHING was renamed; is RESTORE_EXTENSIONS.md complete?")
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()
todo, bad, done = [], 0, 0
for cur, orig, size, want in rows:
    pc, po = os.path.join(here, cur), os.path.join(here, orig)
    p = pc if os.path.isfile(pc) else po if os.path.isfile(po) else None
    if p is None:
        print("MISSING", cur); bad += 1; continue
    if os.path.getsize(p) != size or sha(p) != want:
        print("CHECKSUM MISMATCH", p); bad += 1; continue
    if p == pc and cur != orig:
        todo.append((pc, po))
    elif p == po and cur != orig:
        done += 1
if bad:
    sys.exit(f"{bad} problem(s) -- NOTHING was renamed; re-copy the zip and try again")
for a, b in todo:
    os.rename(a, b)
print(f"restored {len(todo)} files ({done} already restored, {len(rows)} in the manifest), 0 checksum mismatches")
```

## Restore script — PowerShell (alternative)

```powershell
$here = Split-Path -Parent $MyInvocation.MyCommand.Path; if (-not $here) { $here = (Get-Location).Path }
$md = Get-Content -Raw -Encoding UTF8 (Join-Path $here "RESTORE_EXTENSIONS.md")
$parts = $md -split "<!-- MANIFEST-BEGIN -->"; $block = ($parts[$parts.Count - 1] -split "<!-- MANIFEST-END -->")[0]   # the LAST begin-marker
$todo = @(); $bad = 0; $n = 0
foreach ($line in ($block -split "`n")) {
  $c = $line.Split('|') | ForEach-Object { $_.Trim().Trim('`') }
  if ($c.Count -le 6 -or $c[1] -notmatch '^\d+$') { continue }
  $n++
  $cur = Join-Path $here $c[2]; $orig = Join-Path $here $c[3]; $want = $c[6].ToLower()
  if (Test-Path -LiteralPath $cur) { $p = $cur } elseif (Test-Path -LiteralPath $orig) { $p = $orig } else { Write-Host "MISSING $($c[2])"; $bad++; continue }
  if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne $want) { Write-Host "CHECKSUM MISMATCH $p"; $bad++; continue }
  if ($p -eq $cur -and $c[2] -ne $c[3]) { $todo += ,@($cur, $orig) }
}
if ($n -ne 92) { throw "read $n manifest rows, expected 92 -- NOTHING was renamed; is RESTORE_EXTENSIONS.md complete?" }
if ($bad) { throw "$bad problem(s) -- NOTHING was renamed; re-copy the zip and try again" }
foreach ($t in $todo) { Move-Item -LiteralPath $t[0] -Destination $t[1] }
Write-Host "restored $($todo.Count) files, 0 checksum mismatches"
```

## Files by original extension

| original extension | files |
|---|---|
| `.csv` | 38 |
| `.py` | 22 |
| `.md` | 13 |
| `.txt` | 9 |
| `.DAT` | 3 |
| `.AGF` | 1 |
| `.fsp` | 1 |
| `.json` | 1 |
| `.pdf` | 1 |
| `.zar` | 1 |
| `.ZDA` | 1 |
| `.zmx` | 1 |

## Manifest — every file, its name in this zip, its original name and extension

Paths are relative to the `remote_pack` folder. Size in bytes; SHA-256 of the content (unchanged by
the rename).

<!-- MANIFEST-BEGIN -->
| # | name in this zip | original name | original extension | bytes | SHA-256 |
|---|---|---|---|---|---|
| 1 | `CLAUDE.txt` | `CLAUDE.md` | `.md` | 1395 | `b79b33f0ef2bb9399373d0c6887e70721f86be15de7ce2d016a3ae305ba423f8` |
| 2 | `code/cases.txt` | `code/cases.py` | `.py` | 5386 | `d0038831b29b5958f5c6267df3379ab4af01e36dd1deebb505f4d72b91e13445` |
| 3 | `code/check_env.txt` | `code/check_env.py` | `.py` | 2411 | `da8412f89efdeb1fd1a696b711095e17239d28af946bb037532b181c38751eb6` |
| 4 | `code/compare.txt` | `code/compare.py` | `.py` | 17817 | `0e3253deb92c30c805946ae2ff8a91a6054e68a575b7926714ec851c1fd6bc8c` |
| 5 | `code/fpsm.txt` | `code/fpsm.py` | `.py` | 12199 | `459b9cc807069853d972c9b392f51c17a75019e1f048e86dcc5024ac8f5363c8` |
| 6 | `code/kogelnik.txt` | `code/kogelnik.py` | `.py` | 5961 | `506fd9ff3af155f705da7c78d0f6b21abf7fcb1a58d3ff8cf2ed2b459fe7b00c` |
| 7 | `code/kogelnik_te.txt` | `code/kogelnik_te.py` | `.py` | 2354 | `0a566c637c685082beda305c49c0d17860f6b45444e7ecd0a7e869bd59f4493b` |
| 8 | `code/lumerical_rcwa.txt` | `code/lumerical_rcwa.py` | `.py` | 51172 | `0d9ec221bd5dc36bce05c1a796ad4a12b67b01175ea7941ee5db2dc2172ba945` |
| 9 | `code/map2d.txt` | `code/map2d.py` | `.py` | 3813 | `24f8855b7bd30f342a15f89d4848f75acbbdceeae4a21732034c4e95144fbb02` |
| 10 | `code/rcwa.txt` | `code/rcwa.py` | `.py` | 7344 | `f689bf6da241fe31816ca94132f18d848cb360083fe3a72881e9433d4b88eba3` |
| 11 | `code/rcwa_te.txt` | `code/rcwa_te.py` | `.py` | 4025 | `4dfe4c4da9e4a3da085949e5b413fad37dbef9732d9d9818fb56a124f62b8f0c` |
| 12 | `code/reference_values_tm.txt` | `code/reference_values_tm.py` | `.py` | 4267 | `08b91f2e3f6030597bf03a64c9fd62ac4aac1593e49f6c6998a41ce41e862603` |
| 13 | `code/stress_scan.txt` | `code/stress_scan.py` | `.py` | 13947 | `ee9f5a49906aa298593bce780ab226fc161400c38978ca502e4d49e6cf852b58` |
| 14 | `code/stress_summary.txt` | `code/stress_summary.py` | `.py` | 3823 | `b47f6b77b6c1113a06b318e3a9cd7eb56193dd34fd2c96ec1b68a7ba6e6a527a` |
| 15 | `code/summary_chart.txt` | `code/summary_chart.py` | `.py` | 8125 | `1818d80ede73b0fded6a6c3feae5e85286f44dbf55ee1b5138afbe3f2c35e141` |
| 16 | `code/test_engines.txt` | `code/test_engines.py` | `.py` | 3174 | `d29babf3871de006d95a45f84bda242d656585827d34eaa94256c8593867324c` |
| 17 | `code/test_fpsm_vectors.txt` | `code/test_fpsm_vectors.py` | `.py` | 5805 | `fc430ffe1489653519f9b4f3e162a00ec77c9ed1b0af336513ccd02ca9b47d5e` |
| 18 | `code/test_kogelnik_pol.txt` | `code/test_kogelnik_pol.py` | `.py` | 4569 | `673e64bae047041be47e6c3688170be65bc1c975bb0a1623f6b5cf1c76116b02` |
| 19 | `code/test_tm_referee.txt` | `code/test_tm_referee.py` | `.py` | 10427 | `4e8d85e9b286189de74080faf2462516b96de0f60624e2b75a0c1ed57e24386d` |
| 20 | `code/zemax_kogelnik_nsc.txt` | `code/zemax_kogelnik_nsc.py` | `.py` | 8804 | `7b9dbe3acca26e98f2c641963ee0da84d80c7d7ab5c9cc3fedac9fa66da13eb8` |
| 21 | `code/zemax_rcwa_nsc.txt` | `code/zemax_rcwa_nsc.py` | `.py` | 19251 | `be27eb74c80201b2b0eef1ea542b1f9088a4b8a6db0900327a0de9c45c222e69` |
| 22 | `code/zemax_rcwa_probe2.txt` | `code/zemax_rcwa_probe2.py` | `.py` | 3761 | `b1ae6cfcca1c7b2a2e274f95511cabd736c09a94edc00c8d08a10928c9bd8c3b` |
| 23 | `code/zos_connect.txt` | `code/zos_connect.py` | `.py` | 1983 | `1d4e54015ee799cf5b77c962a54d329ff1eb841d70929f0a7467b87a5862b858` |
| 24 | `evidence/kogelnik_gates.txt` | `evidence/kogelnik_gates.txt` | `.txt` | 11262 | `c4614edfa05dc9910c910890b6f6105f2078c5eb26a405efe056d8da7d8fb7cd` |
| 25 | `evidence/tm_referee_gates.txt` | `evidence/tm_referee_gates.txt` | `.txt` | 24825 | `38c108dbc40e4a1fbb321e3330a22487911d8f789916c6281bb8ceaf0647723e` |
| 26 | `evidence/tm_reference_values.txt` | `evidence/tm_reference_values.md` | `.md` | 3136 | `eec1003ef91ed7602df55cb93a040cb31e8176f004e48a197dcf39955fc7e32f` |
| 27 | `EXECUTION_TM_LUMERICAL.txt` | `EXECUTION_TM_LUMERICAL.md` | `.md` | 18401 | `7dce42554b664804424645135fad8ac12c0e86ba07def4cdd5d9ca42a20334b5` |
| 28 | `EXECUTION_TM_OPTICSTUDIO.txt` | `EXECUTION_TM_OPTICSTUDIO.md` | `.md` | 17829 | `29c76aff09f3a8be613b8cf70a701bcfacc8c1d39cab96b30a566e5cc3824f49` |
| 29 | `FPSM_Simple_Implementation.txt` | `FPSM_Simple_Implementation.pdf` | `.pdf` | 265694 | `15b7cd9de1f545670b62f52d51ff1a748a4536093fb0f80a8846ea47789f4b52` |
| 30 | `INSTRUCTIONS_LUMERICAL_PC.txt` | `INSTRUCTIONS_LUMERICAL_PC.md` | `.md` | 11497 | `d8bb48e27b8ee1945d0407da1fa7c0465b8600ddcaab5f90edf43330596c6716` |
| 31 | `INSTRUCTIONS_OPTICSTUDIO_PC.txt` | `INSTRUCTIONS_OPTICSTUDIO_PC.md` | `.md` | 11464 | `699afb77d60deae48276160cd5bb07ad80e26be3d48f347aebfbe2731ff6b77b` |
| 32 | `lumerical/ansys_example/license.txt` | `lumerical/ansys_example/license.txt` | `.txt` | 143 | `3539737e9548f41f5474612614246f7acbdee264c71805f37491f191a3aeeed4` |
| 33 | `lumerical/ansys_example/metadata.txt` | `lumerical/ansys_example/metadata.json` | `.json` | 118 | `5db9eb615cca74eac4b93039bd4e19ac57c67c6d59858753aa52e60c77ec352b` |
| 34 | `lumerical/ansys_example/vhg_R_6um_model.txt` | `lumerical/ansys_example/vhg_R_6um_model.fsp` | `.fsp` | 4667156 | `e593b7368ea326840700e08644da0201ad5075ad8e96d036c9abba4dc6acc7e5` |
| 35 | `README_PACK.txt` | `README_PACK.md` | `.md` | 5661 | `bd41d69cbfb9e68a0fbe47cc4a1f32324c5fb87c05dbe0a97701a03b8b059563` |
| 36 | `reference/ansys_article_36965778575379_layer_repetition.txt` | `reference/ansys_article_36965778575379_layer_repetition.txt` | `.txt` | 9651 | `b99099fa928c91559357a26ceb7b5c23a730e9f6d17cc8f42b7100d1142fa639` |
| 37 | `reference/ansys_article_37118679173267_VHG_lumerical.txt` | `reference/ansys_article_37118679173267_VHG_lumerical.txt` | `.txt` | 11926 | `09dddfb691a533ec705a8d8a369e5ef7f55d1e38a5ec7aae33d9da2f82fe98f9` |
| 38 | `reference/ansys_article_42661816933139_zemax_rcwa_dll.txt` | `reference/ansys_article_42661816933139_zemax_rcwa_dll.txt` | `.txt` | 9246 | `455d0176608f2a0c31147243310e5e14fcb736ddc46ab8d4b84404cfa4ee4dc3` |
| 39 | `reference/ansys_rcwa_verdict_opticstudio.txt` | `reference/ansys_rcwa_verdict_opticstudio.md` | `.md` | 19791 | `cd5e361d83be455faf7f54ce9745b7c5990d3490721a6d24ea729dac04262eb9` |
| 40 | `reference/EXECUTION_LUMERICAL_original.txt` | `reference/EXECUTION_LUMERICAL_original.md` | `.md` | 19896 | `9b6cfb2efb9bebcf624a15aed0398bd50909ea758196a6545aeadf2dfe95f289` |
| 41 | `reference/execution_original.txt` | `reference/execution_original.md` | `.md` | 21866 | `bd540381042abde512315615737f6471b21479ec93cf3c4f1fe2399eed18b464` |
| 42 | `reference/lumerical_converge_lumerical_R_2026-09-18.txt` | `reference/lumerical_converge_lumerical_R_2026-09-18.txt` | `.txt` | 677 | `a41dd0f38e08c22e37cc0948d06bbd219c8e02703d8a68eeb2fe6a75a4f37ae7` |
| 43 | `reference/lumerical_probe_2026-09-18.txt` | `reference/lumerical_probe_2026-09-18.txt` | `.txt` | 104105 | `bdb8acb356cda0bb5a88dbf06d367e02e9012cdfb6305f64b1185a211c6cf3a0` |
| 44 | `reference/lumerical_verdict.txt` | `reference/lumerical_verdict.md` | `.md` | 24481 | `1c868c87ec7ea6b31833e716b6660ab8532599087fd5e3ba111d4b9a94e2a360` |
| 45 | `reference/summary_2026-09-30.txt` | `reference/summary_2026-09-30.csv` | `.csv` | 2827 | `bb1e0770dd8b73b7ecd344b6729ce0427ecda3d12d993a9e83c1cb34f6502c04` |
| 46 | `reference/zemax_rcwa_probe2_2026-09-18.txt` | `reference/zemax_rcwa_probe2_2026-09-18.txt` | `.txt` | 2283 | `a935333d54f9f9bacd60158d866af867a840550fb6d9378cbefdb407dceb1230` |
| 47 | `results/compare_lumerical_R_angle.txt` | `results/compare_lumerical_R_angle.csv` | `.csv` | 14842 | `0100a545eacc07d6907748d8c116ba39dd4ab7edbcf77f4dab50a75a160e50c9` |
| 48 | `results/compare_lumerical_R_TM_angle.txt` | `results/compare_lumerical_R_TM_angle.csv` | `.csv` | 17622 | `e4a55dd2780f74c079bd6d13074f661bf139505787210dcd4c92b234b54dd09b` |
| 49 | `results/compare_lumerical_R_TM_wavelength.txt` | `results/compare_lumerical_R_TM_wavelength.csv` | `.csv` | 11168 | `b0183aac94be256f84a23f37595bf1fe2f28d05f8a56db62c7d7fe9646691079` |
| 50 | `results/compare_lumerical_R_wavelength.txt` | `results/compare_lumerical_R_wavelength.csv` | `.csv` | 9408 | `62bc037a10414edd005f5f73ca48ef2e059eb872b80b36c3818b635a4d036d33` |
| 51 | `results/compare_lumerical_T_angle.txt` | `results/compare_lumerical_T_angle.csv` | `.csv` | 13078 | `6be0fe333c75b5bd17b3ca55e00c59886fbb5c2cad917bd1f7b08f30f92f7877` |
| 52 | `results/compare_lumerical_T_TM_angle.txt` | `results/compare_lumerical_T_TM_angle.csv` | `.csv` | 15518 | `0ca8f85957a9c49c274574130577f11da6d4e4b8e879f5df2d2e49f8dabd253f` |
| 53 | `results/compare_lumerical_T_TM_wavelength.txt` | `results/compare_lumerical_T_TM_wavelength.csv` | `.csv` | 11258 | `32226d37bcab19cff555ae934f2d49cb1d44acf84d3cd3962d6f07ccd715ebf9` |
| 54 | `results/compare_lumerical_T_wavelength.txt` | `results/compare_lumerical_T_wavelength.csv` | `.csv` | 9498 | `b1bf903132679d1b858fe3c7ab48b117f5b6d5159fdb1432fc1fc08ae20ef7e2` |
| 55 | `results/compare_unslanted_T_angle.txt` | `results/compare_unslanted_T_angle.csv` | `.csv` | 18396 | `843424da98373a23f0f174e8859f66057d77d71e9e2413908c66ae48265e8943` |
| 56 | `results/compare_unslanted_T_rot5_angle.txt` | `results/compare_unslanted_T_rot5_angle.csv` | `.csv` | 18396 | `b88ce1f758823319ed43726b90902ea926c57ca226c458e5468db5d4ddf2c406` |
| 57 | `results/compare_unslanted_T_rot5_TM_angle.txt` | `results/compare_unslanted_T_rot5_TM_angle.csv` | `.csv` | 21856 | `2a050ff9b5e9b5553d420e29b53f563ae586b9b6610d089542f82878374f229e` |
| 58 | `results/compare_unslanted_T_rot5_TM_wavelength.txt` | `results/compare_unslanted_T_rot5_TM_wavelength.csv` | `.csv` | 11157 | `eeac3bda471b36f62f24b9c6ceb3338d47d9d8b8b07d6dd4cd4af787c97e8efe` |
| 59 | `results/compare_unslanted_T_rot5_wavelength.txt` | `results/compare_unslanted_T_rot5_wavelength.csv` | `.csv` | 9397 | `ba327462317602b7c50a73e0e5f8428d7746fc42b6fcef98b92c7d9bef7e8fe1` |
| 60 | `results/compare_unslanted_T_TM_angle.txt` | `results/compare_unslanted_T_TM_angle.csv` | `.csv` | 21856 | `e888c49ca679523bbd5a736603ee3d9c8c1e41128671e9c7f30d9e5b0e5e56ee` |
| 61 | `results/compare_unslanted_T_TM_wavelength.txt` | `results/compare_unslanted_T_TM_wavelength.csv` | `.csv` | 11157 | `7a79d96ff985644e93109cc6d6e640f059d89361ebcd7234f62fdd58347836de` |
| 62 | `results/compare_unslanted_T_wavelength.txt` | `results/compare_unslanted_T_wavelength.csv` | `.csv` | 9397 | `e63ffe4e27c4bef470eba446ad37d8b7a348ce49700931a54db203adce59e6fe` |
| 63 | `results/compare_zemax_kba_R_angle.txt` | `results/compare_zemax_kba_R_angle.csv` | `.csv` | 17428 | `66535cfca985b86832cd982ea7bad4ca9043bcaf86cf9229727b1ab299f19721` |
| 64 | `results/compare_zemax_kba_R_TM_angle.txt` | `results/compare_zemax_kba_R_TM_angle.csv` | `.csv` | 20974 | `1f9be733cfb2871ebcf65ce95953a6c29461c778a202f56cb8376d78e7605f1b` |
| 65 | `results/compare_zemax_kba_R_TM_wavelength.txt` | `results/compare_zemax_kba_R_TM_wavelength.csv` | `.csv` | 11169 | `f2789bbc6b6010e0e19bcc87eef44a416ce2e657dbb2d7c65b110ccd54835cca` |
| 66 | `results/compare_zemax_kba_R_wavelength.txt` | `results/compare_zemax_kba_R_wavelength.csv` | `.csv` | 9409 | `62cf72b30897eecad8731af25dde1afe18cf74361a6b6c3f2367fb0293b7f427` |
| 67 | `results/lumerical_rcwa_lumerical_R.txt` | `results/lumerical_rcwa_lumerical_R.csv` | `.csv` | 34624 | `1625ea673e1ba702f36845ea1fbe456591f7a36690685743cef39f0d9b1198b7` |
| 68 | `results/lumerical_rcwa_lumerical_T.txt` | `results/lumerical_rcwa_lumerical_T.csv` | `.csv` | 31198 | `8cb42f748ab7e9873228536e042c7a50745be5e58644f8caaa76f4bf8d8e67b9` |
| 69 | `results/lumerical_rcwa_unslanted_T.txt` | `results/lumerical_rcwa_unslanted_T.csv` | `.csv` | 36049 | `99780e3a50aa05f7a9c5e67716cf507bc7463ff97c5b70b489b8593f699e47c8` |
| 70 | `results/lumerical_rcwa_unslanted_T_rot5.txt` | `results/lumerical_rcwa_unslanted_T_rot5.csv` | `.csv` | 35599 | `91b31feda6bfa4c4572bdc2cd4c20ab1a526ff500146c662eb49c523adfc4810` |
| 71 | `results/lumerical_rcwa_zemax_kba_R.txt` | `results/lumerical_rcwa_zemax_kba_R.csv` | `.csv` | 39387 | `0bdabb3071fb0b901f07dfb7b47b7a1f1938c9fbaa343b91187482438857cfc5` |
| 72 | `results/summary.txt` | `results/summary.csv` | `.csv` | 1065 | `35ffb4ebaa9a4d4ab7492a1a144e84c9ab29b393e55308026574eac205b0d018` |
| 73 | `results/summary_TM.txt` | `results/summary_TM.csv` | `.csv` | 1021 | `6f27f4c9c82b9d22852a239aa295f863ffc016a442ef9be2ae57e2da88ddaad5` |
| 74 | `results/zemax_lumerical_R.txt` | `results/zemax_lumerical_R.csv` | `.csv` | 12352 | `653306772cc4975ad3a3a5463fd6cf83e29179406e0152a458bb65bb9939e1b3` |
| 75 | `results/zemax_lumerical_T.txt` | `results/zemax_lumerical_T.csv` | `.csv` | 11867 | `2c86ff0331b0aef447d4191c5523c3394c1b427c7984c3a11f782f3f663bcea0` |
| 76 | `results/zemax_rcwa_lumerical_R.angle_only_run1.txt` | `results/zemax_rcwa_lumerical_R.angle_only_run1.csv` | `.csv` | 12950 | `48466c3c65ea96ef7679520f7107f68c9888705b4f08d6d2d5a04f64751a72cc` |
| 77 | `results/zemax_rcwa_lumerical_R.txt` | `results/zemax_rcwa_lumerical_R.csv` | `.csv` | 22484 | `f06c797d6aa090558c0d3df4b87cbed06298c294e4bfa41ca7b0af0df08642b2` |
| 78 | `results/zemax_rcwa_lumerical_T.txt` | `results/zemax_rcwa_lumerical_T.csv` | `.csv` | 31654 | `2c25d9faa247b36600a82c84369e214ef4e43015e3004edc3c18da9fecc361aa` |
| 79 | `results/zemax_rcwa_unslanted_T.FAILED.txt` | `results/zemax_rcwa_unslanted_T.FAILED.csv` | `.csv` | 168 | `4e2eade4e44e161ab7a986512c33d4f5836bddfaf260d61e27e0b5c4c8fc3f68` |
| 80 | `results/zemax_rcwa_unslanted_T_rot5.txt` | `results/zemax_rcwa_unslanted_T_rot5.csv` | `.csv` | 30148 | `84399db51d1c050a21420d2c7dd3b8fb9ae3e9028aefdad9b87107d2745f4b1d` |
| 81 | `results/zemax_rcwa_zemax_kba_R.txt` | `results/zemax_rcwa_zemax_kba_R.csv` | `.csv` | 24285 | `ff353dcc619ca98889b29eaf76f58f9ec4a1b975ed917dace5cc40bc823d24a9` |
| 82 | `results/zemax_unslanted_T.txt` | `results/zemax_unslanted_T.csv` | `.csv` | 18160 | `030727b2e48d41098df6a18c511c2ffa0553ddee2b82d8f0568c9967de412147` |
| 83 | `results/zemax_zemax_kba_R.txt` | `results/zemax_zemax_kba_R.csv` | `.csv` | 13236 | `54ac0e73b58131e6493a2417e1132e9956c9862fcf046395d16002fabe826dca` |
| 84 | `RETURN.txt` | `RETURN.md` | `.md` | 2984 | `5a66500613f56f356832b13f1c59bf9d103f75ad699a7f5fed21ad26daf7b6c7` |
| 85 | `zemax/ansys_kba/dll/README_DLL_REMOVED.txt` | `zemax/ansys_kba/dll/README_DLL_REMOVED.md` | `.md` | 939 | `b77dead83399594d1bf8d2d3465c7d1f6107b0b4fdaf57858251c232b8e719d6` |
| 86 | `zemax/ansys_kba/test_example1.txt` | `zemax/ansys_kba/test_example1.zar` | `.zar` | 622662 | `a89c18863873ae9e05df6c3c31498ae6411e3405fd6f9f38258401753d9afa18` |
| 87 | `zemax/ansys_kba/test_example1/ABG_DATA/ABG_DATA.txt` | `zemax/ansys_kba/test_example1/ABG_DATA/ABG_DATA.DAT` | `.DAT` | 1561 | `66f2ae9ec6cdbd5631a5405b8038b21d29c71761c14d4821c3629dd6ece7f2a1` |
| 88 | `zemax/ansys_kba/test_example1/COATINGS/COATING.txt` | `zemax/ansys_kba/test_example1/COATINGS/COATING.DAT` | `.DAT` | 249252 | `2b007ef8b26a4f6e1eafbddbdcc4d90a114cd24992c6583de04a6d0f81b21a5e` |
| 89 | `zemax/ansys_kba/test_example1/GLASSCAT/SCHOTT.txt` | `zemax/ansys_kba/test_example1/GLASSCAT/SCHOTT.AGF` | `.AGF` | 487757 | `d3f916be810b5cb76566b9cf75e16813fc062d12a86a4604d281bb0777823256` |
| 90 | `zemax/ansys_kba/test_example1/Profiles/SCATTER_PROFILE.txt` | `zemax/ansys_kba/test_example1/Profiles/SCATTER_PROFILE.DAT` | `.DAT` | 70 | `c4d11e286208afa73399b2d571b127832c3b938ff7cfe8a682e83411ae7acaf4` |
| 91 | `zemax/ansys_kba/test_example1/test_example1_ZDA.txt` | `zemax/ansys_kba/test_example1/test_example1.ZDA` | `.ZDA` | 2206580 | `5c8995d3af9a7605e87f99bbab5829fe0254da9e779a88d23218726a3b66c4b4` |
| 92 | `zemax/ansys_kba/test_example1/test_example1_zmx.txt` | `zemax/ansys_kba/test_example1/test_example1.zmx` | `.zmx` | 65698 | `25194f15a4916604c3a1e7b407ac526f20afee6b7dc2fcd3c114d3a2383dab8c` |
<!-- MANIFEST-END -->
